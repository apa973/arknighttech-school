<?php 
include './includes/header.php'; 

// DATA ARRAY BERITA & KEGIATAN - Supaya lu gampang tambah/ubah kontennya
$berita_utama = [
    "judul" => "SMK ArknightTech Jalin Kerja Sama dengan Tech Company Internasional",
    "kategori" => "Kerja Sama",
    "tanggal" => "28 Mei 2026",
    "ringkasan" => "Langkah besar kembali diambil oleh SMK ArknightTech. Mulai semester depan, siswa jurusan Digital Business dan RPL akan mendapatkan mentor langsung dari Silicon Valley untuk mengembangkan produk digital mereka hingga siap masuk pasar global.",
    "gambar" => "./assets/berita1.jpg",
    "link" => "#"
];

$daftar_berita = [
    [
        "judul" => "Tim volleyball putra SMK ArknightTech Juara 1 Kejuaraan nasional antar sekolah",
        "kategori" => "Prestasi",
        "tanggal" => "20 Mei 2026",
        "ringkasan" => "Tim volleyball putra SMK ArknightTech meraih juara 1 dalam Kejuaraan nasional antar sekolah, mengalahkan 32 tim dari seluruh Indonesia dengan skor telak 3-0 di final.",
        "gambar" => "./assets/berita2.jpg",
        "link" => "#"
    ],
    [
        "judul" => "Workshop UI/UX Design: Membangun Design System yang Scalable Bersama Praktisi Industri",
        "kategori" => "Kegiatan",
        "tanggal" => "15 Mei 2026",
        "ringkasan" => "Jurusan UI/UX mengadakan workshop intensif selama 3 hari untuk mengenalkan standarisasi komponen desain (*Figma Design System*) yang digunakan di industri modern.",
        "gambar" => "./assets/berita3.jpg",
        "link" => "#"
    ],
    [
        "judul" => "Tim valorant SMK ArknightTech Juara 1 Turnamen Esports Antar Sekolah sejakarta",
        "kategori" => "Prestasi",
        "tanggal" => "10 Mei 2026",
        "ringkasan" => "Tim valorant SMK ArknightTech meraih juara 1 dalam Turnamen Esports internasional, mengalahkan 16 tim dari seluruh Jakarta dengan skor telak 3-1 di final.",
        "gambar" => "./assets/berita4.jpg",
        "link" => "#"
    ]
];
?>

<main class="flex-grow container mx-auto px-4 py-6 sm:py-8 space-y-10 sm:space-y-16">
    
    <section class="border-b border-gray-200 dark:border-gray-700 pb-4">
        <span class="text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 px-3 py-1 rounded-full">Informasi Terkini</span>
        <h2 class="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white border-l-4 border-blue-600 pl-3 dark:border-blue-400 mt-4">Berita & Kegiatan</h2>
    </section>

    <section>
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700/50 overflow-hidden flex flex-col lg:flex-row group hover:shadow-xl transition-all duration-300">
            <div class="w-full lg:w-1/2 bg-gray-900 relative min-h-[200px] sm:min-h-[280px] overflow-hidden">
                <img src="<?php echo $berita_utama['gambar']; ?>" 
                     alt="Featured News" 
                     class="w-full h-full object-cover absolute inset-0 group-hover:scale-102 transition duration-500">
                <div class="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent lg:hidden"></div>
            </div>
            
            <div class="w-full lg:w-1/2 p-5 sm:p-8 lg:p-10 flex flex-col justify-center space-y-4 sm:space-y-5">
                <div class="flex items-center gap-3 text-xs font-bold">
                    <span class="px-3 py-1 rounded-md bg-blue-600 text-white shadow-sm shadow-blue-500/20 uppercase tracking-wider">
                        <?php echo $berita_utama['kategori']; ?>
                    </span>
                    <span class="text-gray-400 dark:text-gray-500">
                        <i class="far fa-calendar-alt mr-1"></i> <?php echo $berita_utama['tanggal']; ?>
                    </span>
                </div>
                
                <h3 class="text-xl sm:text-2xl lg:text-3xl font-black text-gray-900 dark:text-white leading-tight tracking-tight group-hover:text-blue-600 dark:group-hover:text-blue-400 transition duration-200">
                    <a href="<?php echo $berita_utama['link']; ?>"><?php echo $berita_utama['judul']; ?></a>
                </h3>
                
                <p class="text-sm text-gray-500 dark:text-gray-400 leading-relaxed font-normal">
                    <?php echo $berita_utama['ringkasan']; ?>
                </p>
                
                <div class="pt-2">
                    <a href="<?php echo $berita_utama['link']; ?>" class="text-sm font-bold text-blue-600 dark:text-blue-400 inline-flex items-center gap-1 group-hover:gap-2 transition-all duration-200">
                        Baca Selengkapnya <i class="fas fa-chevron-right text-xs"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section class="space-y-8">
        <div class="border-b border-gray-200 dark:border-gray-700 pb-2">
            <h4 class="text-lg font-bold text-gray-900 dark:text-white tracking-tight">Artikel & Acara Terbaru</h4>
        </div>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-8">
            <?php foreach ($daftar_berita as $berita) : ?>
                <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-md border border-gray-100/70 dark:border-gray-700/50 flex flex-col overflow-hidden hover:shadow-xl transition-all duration-300 group">
                    
                    <div class="w-full h-48 bg-gray-100 dark:bg-slate-700 relative overflow-hidden">
                        <img src="<?php echo $berita['gambar']; ?>" 
                             alt="<?php echo $berita['judul']; ?>" 
                             class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                        <span class="absolute top-4 left-4 text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 bg-white/90 dark:bg-slate-900/90 text-blue-600 dark:text-blue-400 rounded-md shadow-sm dynamic-badge">
                            <?php echo $berita['kategori']; ?>
                        </span>
                    </div>

                    <div class="p-6 flex flex-col flex-grow justify-between space-y-4">
                        <div class="space-y-2.5">
                            <span class="text-[11px] font-semibold text-gray-400 dark:text-gray-500 block">
                                <i class="far fa-calendar-alt mr-1"></i> <?php echo $berita['tanggal']; ?>
                            </span>
                            <h5 class="font-bold text-base text-gray-900 dark:text-white tracking-wide leading-snug line-clamp-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition duration-200">
                                <a href="<?php echo $berita['link']; ?>"><?php echo $berita['judul']; ?></a>
                            </h5>
                            <p class="text-xs text-gray-500 dark:text-gray-400 leading-relaxed font-normal line-clamp-3">
                                <?php echo $berita['ringkasan']; ?>
                            </p>
                        </div>

                        <div class="pt-2 border-t border-gray-50 dark:border-gray-700/50">
                            <a href="<?php echo $berita['link']; ?>" class="text-xs font-bold text-blue-600 dark:text-blue-400 inline-flex items-center gap-1 group-hover:gap-2 transition-all duration-200">
                                Selengkapnya <i class="fas fa-chevron-right text-[10px]"></i>
                            </a>
                        </div>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>
    </section>

</main>

<?php 
include './includes/footer.php'; 
?>