<?php include './includes/header.php'; ?>

<style>
    .line-clamp-3 { overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 3; line-clamp: 3; }
    @keyframes modalIn { from { opacity: 0; transform: scale(.92) translateY(10px); } to { opacity: 1; transform: scale(1) translateY(0); } }
    .animate-modal { animation: modalIn .25s cubic-bezier(.16,1,.3,1) forwards; }
</style>

<?php
$ekstrakurikuler = [
    // Wajib
    [
        "nama"       => "Web Desainer & App Development",
        "kategori"   => "IT & Teknologi",
        "badge_color"=> "bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300",
        "icon"       => "fas fa-paint-brush",
        "icon_color" => "text-green-500",
        "bg_icon"    => "bg-green-50 dark:bg-green-900/20",
        "hari"       => "Jumat",
        "jam"        => "14.00 – 16.00 WIB",
        "pembina"    => "Kak Alvin Van Reza, S.Kom",
        "kuota"      => "Semua Siswa Kelas X",
        "deskripsi"  => "Ekskul untuk siswa kelas X yang fokus pada pengenalan dasar-dasar desain web dan pengembangan aplikasi mobile. Siswa belajar HTML, CSS, JavaScript, serta konsep UI/UX untuk membuat portofolio digital pribadi.",
        "prestasi"   => ["Juara 1 LT-III Tingkat Kab. 2025", "Penegak Bantara Terbaik 2024"]
    ],
    // IT & Tech
    [
        "nama"       => "Game Development Club",
        "kategori"   => "IT & Teknologi",
        "badge_color"=> "bg-purple-100 text-purple-800 dark:bg-purple-900/40 dark:text-purple-300",
        "icon"       => "fas fa-gamepad",
        "icon_color" => "text-purple-500",
        "bg_icon"    => "bg-purple-50 dark:bg-purple-900/20",
        "hari"       => "Selasa & Kamis",
        "jam"        => "15.00 – 17.00 WIB",
        "pembina"    => "Bpk. Rizky Firmansyah, S.Kom",
        "kuota"      => "30 siswa",
        "deskripsi"  => "Tempat bagi para game enthusiast untuk belajar membuat game dari nol menggunakan Unity & Godot Engine, mulai dari desain level, scripting C#, hingga game publishing di platform indie.",
        "prestasi"   => ["Game Terbaik IGDC 2025", "Top 5 Indie Jam Nasional 2024"]
    ],
    [
        "nama"       => "Robotika & IoT",
        "kategori"   => "IT & Teknologi",
        "badge_color"=> "bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300",
        "icon"       => "fas fa-robot",
        "icon_color" => "text-blue-500",
        "bg_icon"    => "bg-blue-50 dark:bg-blue-900/20",
        "hari"       => "Rabu & Sabtu",
        "jam"        => "13.00 – 16.00 WIB",
        "pembina"    => "Ibu Sari Dewi, S.T., M.T.",
        "kuota"      => "24 siswa",
        "deskripsi"  => "Merancang, membangun, dan memprogram robot menggunakan Arduino & Raspberry Pi. Anggota juga belajar IoT untuk menghubungkan perangkat fisik dengan internet, menciptakan solusi smart system nyata.",
        "prestasi"   => ["Emas LKS Robotika Prov. 2025", "Juara 2 KRCI Nasional 2024"]
    ],
    [
        "nama"       => "Cyber Security Club",
        "kategori"   => "IT & Teknologi",
        "badge_color"=> "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300",
        "icon"       => "fas fa-shield-alt",
        "icon_color" => "text-red-500",
        "bg_icon"    => "bg-red-50 dark:bg-red-900/20",
        "hari"       => "Senin",
        "jam"        => "15.00 – 17.30 WIB",
        "pembina"    => "Bpk. Andi Prasetyo, S.Kom",
        "kuota"      => "20 siswa",
        "deskripsi"  => "Mempelajari etika hacking, keamanan jaringan, dan CTF (Capture The Flag). Siswa dilatih untuk berpikir seperti ethical hacker guna melindungi sistem dari ancaman siber.",
        "prestasi"   => ["Top 10 COMPFEST CTF UI 2025", "Finalis Cyber Jawara 2024"]
    ],
    [
        "nama"       => "AI & Data Science Club",
        "kategori"   => "IT & Teknologi",
        "badge_color"=> "bg-cyan-100 text-cyan-800 dark:bg-cyan-900/40 dark:text-cyan-300",
        "icon"       => "fas fa-brain",
        "icon_color" => "text-cyan-500",
        "bg_icon"    => "bg-cyan-50 dark:bg-cyan-900/20",
        "hari"       => "Kamis",
        "jam"        => "15.00 – 17.00 WIB",
        "pembina"    => "Ibu Nabila Rahmawati, S.Si",
        "kuota"      => "20 siswa",
        "deskripsi"  => "Eksplorasi Machine Learning, Python, dan data visualization. Anggota mengerjakan proyek nyata mulai dari klasifikasi data hingga membangun model prediksi sederhana berbasis dataset publik.",
        "prestasi"   => ["Best Project Hackathon Telkom 2025"]
    ],
    // Bahasa
    [
        "nama"       => "English Club (SPEAK UP!)",
        "kategori"   => "Bahasa & Komunikasi",
        "badge_color"=> "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
        "icon"       => "fas fa-language",
        "icon_color" => "text-amber-500",
        "bg_icon"    => "bg-amber-50 dark:bg-amber-900/20",
        "hari"       => "Rabu",
        "jam"        => "14.00 – 15.30 WIB",
        "pembina"    => "Ibu Grace Oktaviani, S.Pd",
        "kuota"      => "35 siswa",
        "deskripsi"  => "Melatih kemampuan berbicara, menulis, dan membaca dalam Bahasa Inggris melalui debat, public speaking, storytelling, dan simulasi wawancara kerja berbahasa Inggris.",
        "prestasi"   => ["Juara 2 English Debate Kab. 2025", "Best Speaker OSIS IT Forum 2024"]
    ],
    [
        "nama"       => "Japanese Club (日本語部)",
        "kategori"   => "Bahasa & Komunikasi",
        "badge_color"=> "bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-300",
        "icon"       => "fas fa-torii-gate",
        "icon_color" => "text-rose-500",
        "bg_icon"    => "bg-rose-50 dark:bg-rose-900/20",
        "hari"       => "Selasa",
        "jam"        => "14.00 – 15.30 WIB",
        "pembina"    => "Bpk. Kenji Santoso, S.Pd",
        "kuota"      => "30 siswa",
        "deskripsi"  => "Belajar Bahasa Jepang dari Hiragana, Katakana, hingga percakapan dasar. Kegiatan mencakup nonton anime dengan analisis dialog, belajar J-Pop lyrics, dan simulasi percakapan sehari-hari.",
        "prestasi"   => ["Juara 1 Nihongo Contest Prov. 2025"]
    ],
    // Seni & Kreativitas
    [
        "nama"       => "Konten Kreator & Videografi",
        "kategori"   => "Seni & Kreativitas",
        "badge_color"=> "bg-orange-100 text-orange-800 dark:bg-orange-900/40 dark:text-orange-300",
        "icon"       => "fas fa-video",
        "icon_color" => "text-orange-500",
        "bg_icon"    => "bg-orange-50 dark:bg-orange-900/20",
        "hari"       => "Jumat",
        "jam"        => "14.00 – 16.00 WIB",
        "pembina"    => "Bpk. Dimas Arya, S.Sn",
        "kuota"      => "25 siswa",
        "deskripsi"  => "Belajar storytelling visual, teknik pengambilan gambar, video editing menggunakan DaVinci Resolve & Premiere Pro, serta strategi konten media sosial untuk personal branding dan branding sekolah.",
        "prestasi"   => ["500K+ Views konten YouTube sekolah", "Juara 1 Film Pendek Pelajar 2024"]
    ],
    [
        "nama"       => "Digital Art & Ilustrasi",
        "kategori"   => "Seni & Kreativitas",
        "badge_color"=> "bg-pink-100 text-pink-800 dark:bg-pink-900/40 dark:text-pink-300",
        "icon"       => "fas fa-palette",
        "icon_color" => "text-pink-500",
        "bg_icon"    => "bg-pink-50 dark:bg-pink-900/20",
        "hari"       => "Sabtu",
        "jam"        => "09.00 – 11.00 WIB",
        "pembina"    => "Ibu Aulia Fitri, S.Ds",
        "kuota"      => "25 siswa",
        "deskripsi"  => "Menggambar karakter, ilustrasi digital, dan desain grafis menggunakan Procreate, Clip Studio Paint, dan Adobe Illustrator. Cocok bagi yang ingin jadi UI Artist, Game Artist, atau Graphic Designer.",
        "prestasi"   => ["Juara 1 Poster Digital Tingkat Prov. 2025"]
    ],
    // Olahraga
    [
        "nama"       => "E-Sport Club (MLBB & Valorant)",
        "kategori"   => "Olahraga & E-Sport",
        "badge_color"=> "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/40 dark:text-indigo-300",
        "icon"       => "fas fa-trophy",
        "icon_color" => "text-indigo-500",
        "bg_icon"    => "bg-indigo-50 dark:bg-indigo-900/20",
        "hari"       => "Senin & Rabu",
        "jam"        => "16.00 – 18.00 WIB",
        "pembina"    => "Bpk. Farhan Hidayat, S.Kom",
        "kuota"      => "20 siswa",
        "deskripsi"  => "Tim e-sport resmi sekolah yang berkompetisi di turnamen Mobile Legends dan Valorant tingkat pelajar. Latihan taktik, analisis replay, dan pembentukan mental kompetitif para atlet digital.",
        "prestasi"   => ["Runner-up Pelajar Cup MLBB Jabodetabek 2025", "Top 8 Valorant School League 2024"]
    ],
    [
        "nama"       => "Basket & Futsal",
        "kategori"   => "Olahraga & E-Sport",
        "badge_color"=> "bg-teal-100 text-teal-800 dark:bg-teal-900/40 dark:text-teal-300",
        "icon"       => "fas fa-basketball-ball",
        "icon_color" => "text-teal-500",
        "bg_icon"    => "bg-teal-50 dark:bg-teal-900/20",
        "hari"       => "Selasa & Jumat",
        "jam"        => "15.30 – 17.30 WIB",
        "pembina"    => "Bpk. Teguh Wibowo, S.Or",
        "kuota"      => "30 siswa",
        "deskripsi"  => "Pengembangan fisik, kerja tim, dan sportivitas melalui latihan basket dan futsal rutin. Rutin mengikuti turnamen antar sekolah tingkat kota dan provinsi.",
        "prestasi"   => ["Juara 2 Basket Pelajar Se-Kota 2025"]
    ],
    [
        "nama"       => "Volleyball",
        "kategori"   => "Olahraga & E-Sport",
        "badge_color"=> "bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300",
        "icon"       => "fas fa-volleyball-ball",
        "icon_color" => "text-sky-500",
        "bg_icon"    => "bg-green-50 dark:bg-green-900/20",
        "hari"       => "Selasa & Jumat",
        "jam"        => "13.00 – 15.00 WIB",
        "pembina"    => "Bpk. Raditya Putra, S.Or",
        "kuota"      => "30 siswa",
        "deskripsi"  => "Pengembangan fisik, kerja tim, dan sportivitas melalui latihan basket dan futsal rutin. Rutin mengikuti turnamen antar sekolah tingkat kota dan provinsi.",
        "prestasi"   => ["Juara 2 Basket Pelajar Se-Kota 2025"]
    ]
];

// Ambil semua kategori unik
$kategori_list = array_unique(array_column($ekstrakurikuler, 'kategori'));
$total_eskul   = count($ekstrakurikuler);
?>

<main class="flex-grow">

    <!-- HERO SECTION -->
    <div class="relative bg-gradient-to-br from-blue-900 via-darkblue-800 to-indigo-900 dark:from-darkblue-900 dark:via-darkblue-900 dark:to-indigo-950 overflow-hidden">
        <!-- Grid background pattern -->
        <div class="absolute inset-0 opacity-10"
             style="background-image: linear-gradient(rgba(255,255,255,.07) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.07) 1px, transparent 1px); background-size: 40px 40px;">
        </div>
        <!-- Glowing blobs -->
        <div class="absolute -top-24 -right-24 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute -bottom-24 -left-24 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none"></div>

        <div class="container mx-auto px-4 py-10 sm:py-16 md:py-24 relative z-10 text-center">
            <span class="inline-block bg-blue-500/20 border border-blue-500/30 text-blue-300 text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-widest mb-5">
                <i class="fas fa-star mr-1.5 text-yellow-400"></i>Kegiatan Siswa
            </span>
            <h1 class="text-2xl sm:text-3xl md:text-5xl font-black text-white leading-tight mb-4">
                Ekstrakurikuler <span class="text-blue-400">ArknightTech</span>
            </h1>
            <p class="text-blue-200/80 max-w-xl mx-auto text-sm md:text-base leading-relaxed mb-10">
                Kembangkan potensi terbaikmu di luar kelas! Dari dunia coding, robotik, seni digital, hingga e-sport — ada tempat untukmu berkembang di sini.
            </p>

            <!-- Stats bar -->
            <div class="inline-flex flex-wrap justify-center gap-6 md:gap-10 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl px-8 py-5">
                <div class="text-center">
                    <div class="text-2xl sm:text-3xl font-black text-white"><?php echo $total_eskul; ?></div>
                    <div class="text-xs text-blue-300 mt-0.5">Jenis Ekskul</div>
                </div>
                <div class="w-px bg-white/10 self-stretch hidden sm:block"></div>
                <div class="text-center">
                    <div class="text-2xl sm:text-3xl font-black text-white"><?php echo count($kategori_list); ?></div>
                    <div class="text-xs text-blue-300 mt-0.5">Kategori</div>
                </div>
                <div class="w-px bg-white/10 self-stretch hidden sm:block"></div>
                <div class="text-center">
                    <div class="text-2xl sm:text-3xl font-black text-white">1000+</div>
                    <div class="text-xs text-blue-300 mt-0.5">Anggota Aktif</div>
                </div>
                <div class="w-px bg-white/10 self-stretch hidden sm:block"></div>
                <div class="text-center">
                    <div class="text-2xl sm:text-3xl font-black text-white">500+</div>
                    <div class="text-xs text-blue-300 mt-0.5">Prestasi Diraih</div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mx-auto px-4 py-8 sm:py-12 space-y-10 sm:space-y-14">

        <!-- FILTER TABS -->
        <div class="flex flex-wrap gap-2 justify-center px-2" id="filter-tabs">
            <button onclick="filterEskul('semua')" data-filter="semua"
                class="filter-btn active-filter px-5 py-2 rounded-full text-sm font-bold border-2 border-blue-600 bg-blue-600 text-white transition-all duration-200">
                Semua
            </button>
            <?php foreach ($kategori_list as $kat) : ?>
            <button onclick="filterEskul('<?php echo htmlspecialchars($kat); ?>')" data-filter="<?php echo htmlspecialchars($kat); ?>"
                class="filter-btn px-5 py-2 rounded-full text-sm font-bold border-2 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:border-blue-500 hover:text-blue-600 dark:hover:text-blue-400 transition-all duration-200 bg-white dark:bg-slate-800">
                <?php echo $kat; ?>
            </button>
            <?php endforeach; ?>
        </div>

        <!-- EKSKUL CARDS GRID -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="eskul-grid">
            <?php foreach ($ekstrakurikuler as $eskul) : ?>
            <div class="eskul-card bg-white dark:bg-slate-800 rounded-2xl shadow-md border border-gray-100 dark:border-gray-700/50 hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 flex flex-col overflow-hidden group"
                 data-kategori="<?php echo htmlspecialchars($eskul['kategori']); ?>">

                <!-- Card Header -->
                <div class="p-5 flex items-start gap-4 border-b border-gray-100 dark:border-gray-700/50">
                    <div class="w-14 h-14 shrink-0 rounded-2xl <?php echo $eskul['bg_icon']; ?> flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform duration-300">
                        <i class="<?php echo $eskul['icon']; ?> text-2xl <?php echo $eskul['icon_color']; ?>"></i>
                    </div>
                    <div class="flex-1 min-w-0">
                        <span class="inline-block text-[10px] font-bold px-2.5 py-0.5 rounded-full <?php echo $eskul['badge_color']; ?> mb-1.5 uppercase tracking-wider">
                            <?php echo $eskul['kategori']; ?>
                        </span>
                        <h3 class="font-black text-base text-gray-900 dark:text-white leading-snug">
                            <?php echo $eskul['nama']; ?>
                        </h3>
                    </div>
                </div>

                <!-- Deskripsi -->
                <div class="px-5 pt-4 pb-3 flex-grow">
                    <p class="text-sm text-gray-500 dark:text-gray-400 leading-relaxed line-clamp-3">
                        <?php echo $eskul['deskripsi']; ?>
                    </p>
                </div>

                <!-- Info Grid -->
                <div class="px-5 pb-4 grid grid-cols-2 gap-x-4 gap-y-2 text-xs text-gray-500 dark:text-gray-400">
                    <div class="flex items-center gap-1.5">
                        <i class="fas fa-calendar-day text-blue-400 w-4 shrink-0"></i>
                        <span><?php echo $eskul['hari']; ?></span>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <i class="fas fa-clock text-blue-400 w-4 shrink-0"></i>
                        <span><?php echo $eskul['jam']; ?></span>
                    </div>
                    <div class="flex items-center gap-1.5 col-span-2">
                        <i class="fas fa-chalkboard-teacher text-blue-400 w-4 shrink-0"></i>
                        <span class="truncate"><?php echo $eskul['pembina']; ?></span>
                    </div>
                    <div class="flex items-center gap-1.5 col-span-2">
                        <i class="fas fa-users text-blue-400 w-4 shrink-0"></i>
                        <span>Kuota: <?php echo $eskul['kuota']; ?></span>
                    </div>
                </div>

                <!-- Prestasi (jika ada) -->
                <?php if (!empty($eskul['prestasi'])) : ?>
                <div class="px-5 pb-5">
                    <div class="bg-amber-50 dark:bg-amber-900/20 border border-amber-200/70 dark:border-amber-700/40 rounded-xl p-3 space-y-1">
                        <p class="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider mb-1.5">
                            <i class="fas fa-medal mr-1"></i> Prestasi
                        </p>
                        <?php foreach ($eskul['prestasi'] as $p) : ?>
                        <div class="flex items-start gap-1.5 text-xs text-amber-700 dark:text-amber-300">
                            <i class="fas fa-check-circle mt-0.5 shrink-0 text-amber-500"></i>
                            <span><?php echo $p; ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- CTA Footer -->
                <div class="px-5 pb-5 mt-auto">
                    <button onclick="openModal('<?php echo htmlspecialchars(addslashes($eskul['nama'])); ?>')"
                        class="w-full py-2.5 rounded-xl bg-blue-600/10 text-blue-600 dark:bg-blue-400/10 dark:text-blue-400 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600 dark:hover:text-white font-bold text-sm transition-all duration-200 border border-blue-500/20">
                        <i class="fas fa-info-circle mr-1.5"></i>Info Pendaftaran
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- PANDUAN PENDAFTARAN SECTION -->
        <section>
            <div class="flex items-center gap-3 mb-8">
                <div class="w-1 h-8 bg-blue-600 rounded-full"></div>
                <h2 class="text-2xl font-black text-gray-900 dark:text-white">Cara Daftar Ekstrakurikuler</h2>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
                <?php
                $langkah = [
                    ["no"=>"01","icon"=>"fas fa-user-check","judul"=>"Login E-Learning","desk"=>"Masuk ke portal e-learning menggunakan akun siswa aktifmu.","color"=>"blue"],
                    ["no"=>"02","icon"=>"fas fa-list-ul","judul"=>"Pilih Ekskul","desk"=>"Buka menu Ekstrakurikuler dan pilih ekskul yang kamu minati (maks. 2 ekskul).","color"=>"indigo"],
                    ["no"=>"03","icon"=>"fas fa-file-signature","judul"=>"Isi Formulir","desk"=>"Isi formulir minat online dan unggah foto 3x4 terbaru sebagai identitas anggota.","color"=>"purple"],
                    ["no"=>"04","icon"=>"fas fa-check-double","judul"=>"Konfirmasi","desk"=>"Tunggu konfirmasi dari pembina. Jadwal latihan perdana akan dikirim via grup WhatsApp.","color"=>"green"],
                ];
                foreach ($langkah as $l) :
                ?>
                <div class="relative bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-md border border-gray-100 dark:border-gray-700/50 overflow-hidden hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
                    <span class="absolute top-4 right-4 text-5xl font-black text-<?php echo $l['color']; ?>-100 dark:text-<?php echo $l['color']; ?>-900/30 leading-none select-none"><?php echo $l['no']; ?></span>
                    <div class="w-12 h-12 rounded-xl bg-<?php echo $l['color']; ?>-50 dark:bg-<?php echo $l['color']; ?>-900/20 flex items-center justify-center mb-4 shadow-sm">
                        <i class="<?php echo $l['icon']; ?> text-xl text-<?php echo $l['color']; ?>-500"></i>
                    </div>
                    <h4 class="font-black text-gray-900 dark:text-white mb-1.5"><?php echo $l['judul']; ?></h4>
                    <p class="text-sm text-gray-500 dark:text-gray-400 leading-relaxed"><?php echo $l['desk']; ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- CTA BANNER -->
        <section>
            <div class="relative rounded-2xl overflow-hidden bg-gradient-to-r from-blue-600 to-indigo-700 p-6 sm:p-8 md:p-12 text-white shadow-xl shadow-blue-500/20">
                <div class="absolute inset-0 opacity-10"
                     style="background-image: radial-gradient(circle, rgba(255,255,255,.3) 1px, transparent 1px); background-size: 28px 28px;">
                </div>
                <div class="relative z-10 flex flex-col md:flex-row items-center gap-6 justify-between">
                    <div>
                        <h3 class="text-xl sm:text-2xl md:text-3xl font-black mb-2">Siap Bergabung? 🚀</h3>
                        <p class="text-blue-100 text-sm md:text-base max-w-lg">Jangan lewatkan kesempatan untuk mengembangkan skill dan membangun networking bersama teman-teman terbaik di ArknightTech.</p>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-3 shrink-0 w-full sm:w-auto">
                        <a href="./auth/login.php" class="inline-flex items-center gap-2 bg-white text-blue-600 font-bold px-6 py-3 rounded-xl hover:bg-blue-50 transition-all duration-200 shadow-lg text-sm">
                            <i class="fas fa-sign-in-alt"></i> Login Daftar
                        </a>
                        <a href="kontak.php" class="inline-flex items-center gap-2 bg-white/15 border border-white/30 text-white font-bold px-6 py-3 rounded-xl hover:bg-white/25 transition-all duration-200 text-sm backdrop-blur-sm">
                            <i class="fas fa-question-circle"></i> Tanya Admin
                        </a>
                    </div>
                </div>
            </div>
        </section>

    </div><!-- end container -->
</main>

<!-- MODAL PENDAFTARAN -->
<div id="modal-overlay" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-[999] hidden items-center justify-center p-4" onclick="closeModal(event)">
    <div id="modal-box" class="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl max-w-md w-full p-7 relative animate-modal">
        <button onclick="closeModal(null, true)" class="absolute top-4 right-4 w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-500 hover:bg-red-100 hover:text-red-500 transition">
            <i class="fas fa-times text-sm"></i>
        </button>
        <div class="flex items-center gap-3 mb-4">
            <div class="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center">
                <i class="fas fa-clipboard-list text-blue-500"></i>
            </div>
            <div>
                <h3 class="font-black text-lg text-gray-900 dark:text-white">Info Pendaftaran</h3>
                <p id="modal-ekskul-name" class="text-sm text-blue-500 font-semibold"></p>
            </div>
        </div>
        <div class="space-y-3 text-sm text-gray-600 dark:text-gray-300">
            <div class="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-4 border border-blue-100 dark:border-blue-800/40">
                <p class="font-bold text-blue-700 dark:text-blue-300 mb-2"><i class="fas fa-info-circle mr-1.5"></i>Syarat Pendaftaran</p>
                <ul class="space-y-1.5 list-disc list-inside text-gray-600 dark:text-gray-400 text-xs">
                    <li>Siswa aktif SMK ArknightTech kelas X, XI, atau XII</li>
                    <li>Tidak mengikuti lebih dari 2 ekskul sekaligus</li>
                    <li>Memiliki komitmen hadir minimal 80% setiap pertemuan</li>
                </ul>
            </div>
            <div class="bg-amber-50 dark:bg-amber-900/20 rounded-xl p-4 border border-amber-100 dark:border-amber-800/40">
                <p class="font-bold text-amber-700 dark:text-amber-300 mb-2"><i class="fas fa-calendar-check mr-1.5"></i>Periode Pendaftaran</p>
                <p class="text-xs text-gray-600 dark:text-gray-400">Dibuka setiap awal semester (Juli & Januari). Untuk pendaftaran di luar periode, hubungi langsung pembina ekskul yang bersangkutan.</p>
            </div>
        </div>
        <a href="elearning.php" class="mt-5 w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-all duration-200 shadow-md shadow-blue-500/20 text-sm">
            <i class="fas fa-paper-plane"></i> Daftar via Portal E-Learning
        </a>
    </div>
</div>

<script>
    // FILTER EKSKUL
    function filterEskul(kategori) {
        const cards = document.querySelectorAll('.eskul-card');
        const btns  = document.querySelectorAll('.filter-btn');

        btns.forEach(b => {
            const isActive = b.dataset.filter === kategori;
            b.classList.toggle('active-filter', isActive);
            b.classList.toggle('bg-blue-600', isActive);
            b.classList.toggle('text-white', isActive);
            b.classList.toggle('border-blue-600', isActive);
            b.classList.toggle('bg-white', !isActive);
            b.classList.toggle('dark:bg-slate-800', !isActive);
            b.classList.toggle('text-gray-600', !isActive);
            b.classList.toggle('dark:text-gray-300', !isActive);
            b.classList.toggle('border-gray-200', !isActive);
            b.classList.toggle('dark:border-gray-700', !isActive);
        });

        cards.forEach(c => {
            const show = kategori === 'semua' || c.dataset.kategori === kategori;
            c.style.display = show ? '' : 'none';
        });
    }

    // MODAL
    function openModal(namaEskul) {
        document.getElementById('modal-ekskul-name').textContent = namaEskul;
        const overlay = document.getElementById('modal-overlay');
        overlay.classList.remove('hidden');
        overlay.classList.add('flex');
        // re-trigger animation
        const box = document.getElementById('modal-box');
        box.classList.remove('animate-modal');
        void box.offsetWidth;
        box.classList.add('animate-modal');
    }
    function closeModal(e, force = false) {
        if (force || e.target.id === 'modal-overlay') {
            const overlay = document.getElementById('modal-overlay');
            overlay.classList.add('hidden');
            overlay.classList.remove('flex');
        }
    }
</script>

<?php include './includes/footer.php'; ?>