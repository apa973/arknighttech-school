<?php 
include './includes/header.php'; 

// DATA ARRAY PHP - Agar mudah di-maintenance jika ada perubahan data
$visi = "Menjadi Lembaga Pendidikan Kejuruan Terdepan yang Menghasilkan Lulusan Berkompetensi Global, Berkarakter Wirausaha, dan Menguasai Teknologi Digital Masa Depan.";

$misi = [
    "Menyelenggarakan kurikulum berbasis kebutuhan industri teknologi dan bisnis digital skala internasional.",
    "Menyediakan fasilitas laboratorium pemrograman modern untuk mendukung riset dan inovasi produk digital.",
    "Membangun ekosistem belajar yang adaptif terhadap perkembangan Artificial Intelligence dan Cloud Computing.",
    "Menanamkan jiwa disiplin, integritas tinggi, dan semangat pantang menyerah khas developer juara."
];

$sejarah_singkat = "Didirikan pada era transformasi digital, SMK ArknightTech lahir sebagai jawaban atas tingginya kebutuhan industri akan tenaga ahli di bidang rekayasa perangkat lunak dan bisnis digital. Berawal dari sebuah komunitas riset teknologi, kini sekolah telah berkembang menjadi pusat inkubasi talenta digital muda yang dipercaya oleh belasan tech startup nasional maupun internasional.";

// Array Fasilitas yang sudah disesuaikan dengan Ikon penunjang (Tanpa Link Gambar)
$fasilitas_unggulan = [
    [
        "nama" => "Lab Pemrograman Utama (Mac & PC)",
        "deskripsi" => "Dilengkapi dengan PC berspesifikasi tinggi generasi ke-12 dan ekosistem Mac untuk pengembangan aplikasi iOS/Android.",
        "ikon" => "fas fa-laptop-code text-blue-600 dark:text-blue-400",
        "bg_ikon" => "bg-blue-50 dark:bg-blue-950/50"
    ],
    [
        "nama" => "Lab sains data & AI",
        "deskripsi" => "Fasilitas modern untuk penelitian dan pengembangan dalam bidang data science dan kecerdasan buatan.",
        "ikon" => "fas fa-microscope text-amber-500 dark:text-amber-400",
        "bg_ikon" => "bg-amber-50 dark:bg-amber-950/50"
    ],
    [
        "nama" => "Perpustakaan Digital & Research Center",
        "deskripsi" => "Akses gratis ke ribuan jurnal internasional, e-book teknologi premium, serta ruang tenang untuk riset algoritma.",
        "ikon" => "fas fa-book-reader text-black-600 dark:text-purple-400",
        "bg_ikon" => "bg-sky-50 dark:bg-purple-950/50"
    ],  
    [
        "nama" => "Observatorium Teknologi & Inovasi",
        "deskripsi" => "Ruang khusus untuk penelitian dan pengembangan teknologi terkini serta kolaborasi dengan industri.",
        "ikon" => "fas fa-binoculars text-gray-600 dark:text-purple-400",
        "bg_ikon" => "bg-emerald-50 dark:bg-purple-950/50"
    ],
    [
        "nama" => "Lab Robotika & IoT",
        "deskripsi" => "Fasilitas modern untuk penelitian dan pengembangan dalam bidang robotika dan internet of things.",
        "ikon" => "fas fa-robot text-red-600 dark:text-purple-400",
        "bg_ikon" => "bg-purple-50 dark:bg-purple-950/50"
    ]
];
?>

<main class="flex-grow container mx-auto px-4 py-6 sm:py-8 space-y-10 sm:space-y-16">
    
    <section class="page-section active">
        <div class="relative w-full h-[250px] sm:h-[350px] md:h-[400px] rounded-2xl overflow-hidden shadow-xl bg-gray-900">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10"></div>
            
            
            <img src="./assets/profil1.jpg" 
                 class="w-full h-full object-cover animate-zoom-slider absolute inset-0" 
                 alt="SMK ArknightTech Campus">
            
            <div class="absolute bottom-6 md:bottom-12 left-6 md:left-12 z-20 max-w-3xl text-white pr-6">
                <span class="reveal-text bg-blue-600 px-3 py-1 text-xs font-bold rounded uppercase tracking-wider mb-2 md:mb-3 inline-block" style="animation-delay: 100ms;">Tentang Kami</span>
                <h2 class="reveal-text text-2xl sm:text-3xl md:text-5xl font-black tracking-tight leading-tight mb-2 drop-shadow-lg" style="animation-delay: 250ms;">Profil SMK ArknightTech</h2>
                <p class="reveal-text text-sm text-gray-200 font-medium max-w-xl drop-shadow" style="animation-delay: 400ms;">Mengenal visi, misi, sejarah, dan fasilitas penunjang pencetak developer juara.</p>
            </div>
        </div>
    </section>

    <section class="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
        <div class="bg-white dark:bg-slate-800 p-5 sm:p-8 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700/50 flex flex-col justify-between">
            <div>
                <span class="text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 px-3 py-1 rounded-full">The Dream</span>
                <h3 class="text-2xl font-black text-gray-900 dark:text-white mt-4 mb-4 border-l-4 border-blue-600 pl-3">Visi Sekolah</h3>
                <p class="text-base text-gray-700 dark:text-gray-300 font-medium italic leading-relaxed">"<?php echo $visi; ?>"</p>
            </div>
            <div class="pt-6 hidden lg:block">
                <i class="fas fa-bullseye text-2xl sm:text-4xl text-blue-600/20"></i>
            </div>
        </div>

        <div class="lg:col-span-2 bg-white dark:bg-slate-800 p-5 sm:p-8 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700/50">
            <span class="text-xs font-bold uppercase tracking-widest text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/30 px-3 py-1 rounded-full">The Action</span>
            <h3 class="text-2xl font-black text-gray-900 dark:text-white mt-4 mb-6 border-l-4 border-green-500 pl-3">Misi Sekolah</h3>
            
            <ul class="space-y-4">
                <?php foreach ($misi as $index => $item) : ?>
                    <li class="flex items-start gap-3">
                        <span class="w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                            <?php echo $index + 1; ?>
                        </span>
                        <p class="text-sm text-gray-600 dark:text-gray-300 leading-relaxed"><?php echo $item; ?></p>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </section>

    <section class="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700/50 overflow-hidden flex flex-col md:flex-row">
        <div class="w-full md:w-1/3 bg-gray-100 dark:bg-slate-700 relative min-h-[200px]">
            <img src="./assets/profil2.jpg" 
                 alt="School Tech History" 
                 class="w-full h-full object-cover absolute inset-0">
            <div class="absolute inset-0 bg-blue-900/10 mix-blend-multiply"></div>
        </div>
        <div class="w-full md:w-2/3 p-8 sm:p-10 space-y-4 flex flex-col justify-center">
           <a href="sejarah.php"><h3 class="text-2xl font-black text-gray-900 dark:text-white border-l-4 border-amber-500 pl-3">Sejarah Singkat</h3></a>
            <p class="text-sm text-gray-600 dark:text-gray-300 leading-relaxed tracking-wide">
                <?php echo $sejarah_singkat; ?>
            </p>
            <p class="text-xs font-semibold text-gray-400 dark:text-gray-500">
                <i class="fas fa-history mr-1"></i> Diperbarui secara berkala oleh Tim Manajemen Sekolah.
            </p>
        </div>
    </section>

    <section class="space-y-6">
        <div class="border-b border-gray-200 dark:border-gray-700 pb-4">
            <h3 class="text-2xl font-black text-gray-900 dark:text-white border-l-4 border-purple-600 pl-3 dark:border-purple-400">Fasilitas Infrastruktur Digital</h3>
        </div>
        
        <div class="space-y-4">
            <?php foreach ($fasilitas_unggulan as $fasilitas) : ?>
                <div class="bg-white dark:bg-slate-800 p-5 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700/50 flex items-start gap-5 hover:shadow-md transition-all duration-300 group">
                    
                    <div class="w-12 h-12 rounded-xl <?php echo $fasilitas['bg_ikon']; ?> flex items-center justify-center shrink-0 shadow-sm border border-gray-200/20 group-hover:scale-105 transition duration-200">
                        <i class="<?php echo $fasilitas['ikon']; ?> text-xl"></i>
                    </div>
                    
                    <div class="space-y-1">
                        <h4 class="font-bold text-base text-gray-900 dark:text-white tracking-wide group-hover:text-blue-600 dark:group-hover:text-blue-400 transition duration-200">
                            <?php echo $fasilitas['nama']; ?>
                        </h4>
                        <p class="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                            <?php echo $fasilitas['deskripsi']; ?>
                        </p>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>
    </section>

</main>

<?php 
include './includes/footer.php'; 
?>