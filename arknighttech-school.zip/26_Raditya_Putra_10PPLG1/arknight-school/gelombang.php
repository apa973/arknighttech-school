<?php include './includes/header.php'; ?>

<?php
$gelombang = [
    [
        "nomor"     => 1,
        "label"     => "Gelombang 1",
        "deskripsi" => "Pendaftaran awal tahun ajaran baru",
        "buka"      => "1 Feb – 31 Mar 2026",
        "kuota"     => 60,
        "terdaftar" => 60,
        "status"    => "closed",
        "buka_tgl"  => null,
    ],
    [
        "nomor"     => 2,
        "label"     => "Gelombang 2",
        "deskripsi" => "Gelombang utama — pendaftaran aktif!",
        "buka"      => "1 Apr – 30 Jun 2026",
        "kuota"     => 80,
        "terdaftar" => 50,
        "status"    => "open",
        "buka_tgl"  => null,
    ],
    [
        "nomor"     => 3,
        "label"     => "Gelombang 3",
        "deskripsi" => "Gelombang terakhir, kuota sangat terbatas",
        "buka"      => "1 Jul – 31 Jul 2026",
        "kuota"     => 40,
        "terdaftar" => 0,
        "status"    => "upcoming",
        "buka_tgl"  => "1 Juli 2026",
    ],
];

$tahapan = [
    ["icon" => "fa-file-alt",        "judul" => "Isi Formulir Online",   "deskripsi" => "Lengkapi data diri calon siswa melalui portal pendaftaran online.",  "selesai" => true],
    ["icon" => "fa-upload",          "judul" => "Upload Dokumen",         "deskripsi" => "Unggah fotokopi rapor, ijazah/SKL, foto 3x4, dan KK.",              "selesai" => true],
    ["icon" => "fa-clipboard-check", "judul" => "Seleksi Administrasi",   "deskripsi" => "Tim panitia memverifikasi kelengkapan berkas dalam 3 hari kerja.",   "selesai" => false],
    ["icon" => "fa-laptop-code",     "judul" => "Tes Potensi Digital",    "deskripsi" => "Tes logika, minat jurusan, dan kemampuan dasar TIK secara online.",  "selesai" => false],
    ["icon" => "fa-bullhorn",        "judul" => "Pengumuman Hasil",       "deskripsi" => "Hasil seleksi diumumkan via portal dan email terdaftar.",            "selesai" => false],
    ["icon" => "fa-id-card",         "judul" => "Daftar Ulang",           "deskripsi" => "Calon siswa yang diterima melakukan daftar ulang.",                  "selesai" => false],
];

$faq = [
    ["q" => "Apakah pendaftaran PPDB gratis?",             "a" => "Ya, seluruh proses pendaftaran PPDB SMK ArknightTech tidak dipungut biaya apapun."],
    ["q" => "Dokumen apa saja yang diperlukan?",           "a" => "Fotokopi rapor semester 1-5, ijazah/SKL, foto 3x4 (2 lembar), dan fotokopi Kartu Keluarga."],
    ["q" => "Apakah ada tes masuk?",                       "a" => "Ada. Tes Potensi Digital dilakukan secara online, meliputi logika dasar, minat jurusan, dan literasi teknologi."],
    ["q" => "Bagaimana cara cek status pendaftaran?",      "a" => "Setelah mendaftar, kamu akan mendapat nomor registrasi. Status bisa dicek di portal PPDB."],
    ["q" => "Apakah ada beasiswa untuk siswa berprestasi?","a" => "Ya! Tersedia beasiswa SPP untuk 10 siswa terbaik berdasarkan hasil seleksi."],
];
?>

<main class="flex-grow container mx-auto px-4 py-10 space-y-12">

    <!-- PAGE TITLE -->
    <div class="border-l-4 border-blue-600 pl-4">
        <h1 class="text-3xl font-black text-gray-900 dark:text-white">PPDB 2026/2027 🎓</h1>
        <p class="text-gray-500 dark:text-gray-400 mt-1 text-sm">Penerimaan Peserta Didik Baru SMK ArknightTech — Gratis, Online, dan Mudah.</p>
    </div>

    <!-- GELOMBANG CARDS -->
    <div>
        <h2 class="text-xl font-black text-gray-900 dark:text-white mb-4 border-l-4 border-blue-500 pl-3">Gelombang Pendaftaran</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
        <?php foreach ($gelombang as $gel):
            $pct = $gel['kuota'] > 0 ? round(($gel['terdaftar'] / $gel['kuota']) * 100) : 0;
            if ($gel['status'] === 'open') {
                $pill = "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400";
                $label = "🟢 Sedang Buka";
                $border = "border-blue-400 dark:border-blue-500";
                $bar_color = "bg-blue-500";
            } elseif ($gel['status'] === 'upcoming') {
                $pill = "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400";
                $label = "🟡 Segera Buka";
                $border = "border-yellow-400 dark:border-yellow-500";
                $bar_color = "bg-yellow-400";
            } else {
                $pill = "bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400";
                $label = "⛔ Ditutup";
                $border = "border-gray-200 dark:border-gray-700";
                $bar_color = "bg-gray-300";
            }
        ?>
        <div class="bg-white dark:bg-slate-800 rounded-2xl border-2 <?= $border ?> shadow-sm p-6 flex flex-col gap-3 <?= $gel['status'] === 'closed' ? 'opacity-60' : '' ?>">
            <div class="flex items-center justify-between">
                <h3 class="font-black text-lg text-gray-900 dark:text-white"><?= $gel['label'] ?></h3>
                <span class="text-xs font-bold px-2.5 py-1 rounded-full <?= $pill ?>"><?= $label ?></span>
            </div>
            <p class="text-sm text-gray-500 dark:text-gray-400"><?= $gel['deskripsi'] ?></p>
            <div class="text-sm space-y-1 text-gray-700 dark:text-gray-300">
                <p><i class="fas fa-calendar-alt text-blue-400 w-4 mr-1"></i> <?= $gel['buka'] ?></p>
                <p><i class="fas fa-users text-blue-400 w-4 mr-1"></i> Kuota: <strong><?= $gel['kuota'] ?> Siswa</strong></p>
                <p><i class="fas fa-tag text-blue-400 w-4 mr-1"></i> Biaya: <strong class="text-green-600 dark:text-green-400">Gratis</strong></p>
            </div>
            <!-- Progress Bar -->
            <div>
                <div class="w-full bg-gray-100 dark:bg-gray-700 rounded-full h-2">
                    <div class="<?= $bar_color ?> h-2 rounded-full" style="width: <?= $pct ?>%"></div>
                </div>
                <p class="text-xs text-gray-400 mt-1 text-right"><?= $gel['terdaftar'] ?> / <?= $gel['kuota'] ?> terdaftar</p>
            </div>
            <!-- Action -->
            <?php if ($gel['status'] === 'open'): ?>
                <a href="#daftar" class="mt-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm py-2.5 rounded-xl transition">
                    Daftar Sekarang <i class="fas fa-arrow-right text-xs"></i>
                </a>
            <?php elseif ($gel['status'] === 'upcoming'): ?>
                <p class="text-xs text-yellow-600 dark:text-yellow-400"><i class="fas fa-clock mr-1"></i> Dibuka <?= $gel['buka_tgl'] ?></p>
            <?php else: ?>
                <p class="text-xs text-gray-400"><i class="fas fa-lock mr-1"></i> Pendaftaran telah ditutup</p>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        </div>
    </div>

    <!-- TAHAPAN -->
    <div>
        <h2 class="text-xl font-black text-gray-900 dark:text-white mb-6 border-l-4 border-blue-500 pl-3">Tahapan Pendaftaran</h2>
        <div class="bg-white dark:bg-slate-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm p-6 space-y-5">
        <?php foreach ($tahapan as $i => $step): ?>
            <div class="flex items-start gap-4">
                <div class="w-8 h-8 rounded-xl flex items-center justify-center text-xs shrink-0 <?= $step['selesai'] ? 'bg-blue-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-400' ?>">
                    <i class="fas <?= $step['icon'] ?>"></i>
                </div>
                <div>
                    <div class="flex items-center gap-2 flex-wrap">
                        <h4 class="font-bold text-sm text-gray-900 dark:text-white"><?= $step['judul'] ?></h4>
                        <?php if ($step['selesai']): ?>
                            <span class="text-[10px] font-bold text-green-500 bg-green-100 dark:bg-green-900/30 px-2 py-0.5 rounded-full">Selesai</span>
                        <?php endif; ?>
                    </div>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mt-0.5"><?= $step['deskripsi'] ?></p>
                </div>
            </div>
            <?php if ($i < count($tahapan) - 1): ?>
                <hr class="border-gray-100 dark:border-gray-700 ml-4">
            <?php endif; ?>
        <?php endforeach; ?>
        </div>
    </div>

    <!-- FORM DAFTAR -->
    <div id="daftar">
        <h2 class="text-xl font-black text-gray-900 dark:text-white mb-4 border-l-4 border-blue-500 pl-3">Formulir Pendaftaran Online</h2>
        <div class="bg-white dark:bg-slate-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-sm p-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                <?php
                $fields = [
                    ["label"=>"Nama Lengkap",   "type"=>"text",  "name"=>"nama",        "placeholder"=>"Masukkan nama lengkap", "full"=>true],
                    ["label"=>"Nomor NIK",       "type"=>"text",  "name"=>"nik",         "placeholder"=>"16 digit NIK"],
                    ["label"=>"Tempat Lahir",    "type"=>"text",  "name"=>"ttl_tempat",  "placeholder"=>"Kota/Kabupaten"],
                    ["label"=>"Tanggal Lahir",   "type"=>"date",  "name"=>"ttl_tanggal", "placeholder"=>""],
                    ["label"=>"Nomor WhatsApp",  "type"=>"tel",   "name"=>"wa",          "placeholder"=>"08xx-xxxx-xxxx"],
                    ["label"=>"Email",           "type"=>"email", "name"=>"email",       "placeholder"=>"nama@email.com"],
                ];
                foreach ($fields as $f):
                    $span = !empty($f['full']) ? 'md:col-span-2' : '';
                ?>
                <div class="<?= $span ?>">
                    <label class="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 uppercase tracking-wide"><?= $f['label'] ?></label>
                    <input type="<?= $f['type'] ?>" name="<?= $f['name'] ?>" placeholder="<?= $f['placeholder'] ?>"
                        class="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-200 dark:border-gray-600 bg-white dark:bg-darkblue-900 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition">
                </div>
                <?php endforeach; ?>

                <div class="md:col-span-2">
                    <label class="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 uppercase tracking-wide">Pilihan Jurusan</label>
                    <select name="jurusan" class="w-full px-4 py-2.5 text-sm rounded-xl border border-gray-200 dark:border-gray-600 bg-white dark:bg-darkblue-900 text-gray-900 dark:text-white focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition">
                        <option value="">-- Pilih Jurusan --</option>
                        <option>Rekayasa Perangkat Lunak (RPL)</option>
                        <option>Desain Komunikasi Visual (DKV)</option>
                        <option>Teknik Komputer & Jaringan (TKJ)</option>
                        <option>Sistem Informasi & AI</option>
                        <option>PPLG (perkembangan Perangkat Lunak & Gim)</option>
                    </select>
                </div>

                <div class="md:col-span-2">
                    <label class="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 uppercase tracking-wide">Pilih Gelombang</label>
                    <div class="grid grid-cols-3 gap-3">
                    <?php foreach ($gelombang as $gel):
                        $isOpen   = $gel['status'] === 'open';
                        $disabled = !$isOpen ? 'disabled' : '';
                        $opacity  = !$isOpen ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer';
                        $subLabel = $gel['status'] === 'open' ? '<span class="text-[10px] text-green-500 font-semibold">Buka</span>'
                                  : ($gel['status'] === 'upcoming' ? '<span class="text-[10px] text-yellow-500 font-semibold">Jul 2026</span>'
                                  : '<span class="text-[10px] text-gray-400 font-semibold">Tutup</span>');
                    ?>
                        <label class="<?= $opacity ?>">
                            <input type="radio" name="gelombang" value="<?= $gel['nomor'] ?>" class="sr-only peer" <?= $isOpen ? 'checked' : '' ?> <?= $disabled ?>>
                            <div class="peer-checked:border-blue-500 peer-checked:bg-blue-50 dark:peer-checked:bg-blue-900/30 border-2 border-gray-200 dark:border-gray-700 rounded-xl p-3 text-center transition">
                                <p class="font-bold text-sm text-gray-800 dark:text-white">Gel. <?= $gel['nomor'] ?></p>
                                <?= $subLabel ?>
                            </div>
                        </label>
                    <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <button id="submit-btn" onclick="submitPPDB()" class="mt-6 w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition">
                <i class="fas fa-paper-plane"></i> Kirim Pendaftaran
            </button>
            <p class="text-center text-xs text-gray-400 mt-3">Data kamu aman & hanya digunakan untuk keperluan PPDB</p>
        </div>
    </div>

    <!-- FAQ -->
    <div>
        <h2 class="text-xl font-black text-gray-900 dark:text-white mb-4 border-l-4 border-blue-500 pl-3">FAQ PPDB ❓</h2>
        <div class="space-y-3">
        <?php foreach ($faq as $i => $item): ?>
            <div class="bg-white dark:bg-slate-800 border border-gray-100 dark:border-gray-700 rounded-xl shadow-sm overflow-hidden">
                <button onclick="toggleFaq(<?= $i ?>)" class="w-full flex items-center justify-between px-5 py-4 text-left gap-4">
                    <span class="font-semibold text-sm text-gray-800 dark:text-white"><?= $item['q'] ?></span>
                    <i id="faq-icon-<?= $i ?>" class="fas fa-chevron-down text-blue-500 text-xs shrink-0 transition-transform duration-300"></i>
                </button>
                <div id="faq-body-<?= $i ?>" class="overflow-hidden max-h-0 transition-all duration-300">
                    <p class="text-sm text-gray-500 dark:text-gray-400 px-5 pb-4 leading-relaxed"><?= $item['a'] ?></p>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    </div>

    <!-- CTA -->
    <div class="bg-blue-600 rounded-2xl p-8 text-center text-white">
        <h2 class="text-2xl font-black mb-2">Siap Jadi Developer Masa Depan? 🚀</h2>
        <p class="text-blue-100 text-sm mb-5">Kuota Gelombang 2 tersisa <strong>30 kursi</strong>. Jangan sampai kehabisan!</p>
        <div class="flex flex-wrap justify-center gap-3">
            <a href="#daftar" class="inline-flex items-center gap-2 bg-white text-blue-700 font-bold px-6 py-2.5 rounded-xl hover:bg-blue-50 transition text-sm">
                <i class="fas fa-rocket"></i> Daftar Sekarang
            </a>
            <a href="kontak.php" class="inline-flex items-center gap-2 bg-white/15 border border-white/30 text-white font-semibold px-6 py-2.5 rounded-xl hover:bg-white/25 transition text-sm">
                <i class="fas fa-headset"></i> Hubungi Kami
            </a>
        </div>
    </div>

</main>

<script>
function toggleFaq(i) {
    const body = document.getElementById('faq-body-' + i);
    const icon = document.getElementById('faq-icon-' + i);
    const isOpen = body.style.maxHeight && body.style.maxHeight !== '0px';
    body.style.maxHeight = isOpen ? '0px' : '300px';
    icon.style.transform = isOpen ? '' : 'rotate(180deg)';
}

function submitPPDB() {
    const btn = document.getElementById('submit-btn');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mengirim...';
    btn.disabled = true;
    setTimeout(() => {
        btn.innerHTML = '<i class="fas fa-check-circle"></i> Pendaftaran Terkirim!';
        btn.classList.replace('bg-blue-600', 'bg-green-600');
    }, 1800);
}
</script>

<?php include './includes/footer.php'; ?>