<?php include './includes/header.php'; ?>

<?php
$fasilitas = [
    [
        "kategori" => "Laboratorium",
        "nama"     => "Lab Pemrograman Utama",
        "deskripsi"=> "40 unit PC spek tinggi Intel Core i9 + RAM 32GB. Dual monitor 27\" untuk coding lebih nyaman.",
        "gambar"   => "./assets/lab1.jpg",
        "kapasitas"=> "40 Siswa",
        "icon"     => "fas fa-desktop",
    ],
    [
        "kategori" => "Laboratorium",
        "nama"     => "Lab UI/UX & Desain Digital",
        "deskripsi"=> "Studio desain dengan iMac M2 dan Wacom Cintiq untuk belajar prototyping dan ilustrasi digital.",
        "gambar"   => "./assets/lab2.jpg",
        "kapasitas"=> "30 Siswa",
        "icon"     => "fas fa-paint-brush",
    ],
    [
        "kategori" => "Laboratorium",
        "nama"     => "Lab Jaringan & Cyber Security",
        "deskripsi"=> "Peralatan Cisco, server rack, dan tools ethical hacking untuk simulasi jaringan nyata.",
        "gambar"   => "./assets/lab3.jpg",
        "kapasitas"=> "24 Siswa",
        "icon"     => "fas fa-shield-alt",
    ],
    [
        "kategori" => "Ruang Kelas",
        "nama"     => "Smart Classroom",
        "deskripsi"=> "Papan interaktif 86\", proyektor 4K, dan kursi ergonomis untuk belajar yang lebih aktif dan modern.",
        "gambar"   => "./assets/kelas.jpg",
        "kapasitas"=> "36 Siswa",
        "icon"     => "fas fa-chalkboard-teacher",
    ],
    [
        "kategori" => "Ruang Kelas",
        "nama"     => "Ruang Diskusi & Kolaborasi",
        "deskripsi"=> "Open space dengan whiteboard besar dan standing desk untuk sesi kerja tim dan brainstorming.",
        "gambar"   => "./assets/diskusi.png",
        "kapasitas"=> "20 Siswa",
        "icon"     => "fas fa-users",
    ],
    [
        "kategori" => "Fasilitas Umum",
        "nama"     => "Perpustakaan Digital",
        "deskripsi"=> "5.000+ e-book, jurnal internasional, dan akses platform Udemy & Coursera untuk semua siswa.",
        "gambar"   => "./assets/perpustakaan.jpg",
        "kapasitas"=> "60 Orang",
        "icon"     => "fas fa-book-open",
    ],
    [
        "kategori" => "Fasilitas Umum",
        "nama"     => "Auditorium",
        "deskripsi"=> "Venue seminar dan acara sekolah dengan sound system profesional dan fasilitas live streaming.",
        "gambar"   => "./assets/auditorium.jpg",
        "kapasitas"=> "500 Orang",
        "icon"     => "fas fa-microphone-alt",
    ],
    [
        "kategori" => "Fasilitas Umum",
        "nama"     => "Kantin & Food Court",
        "deskripsi"=> "15+ tenant kuliner, area bersih dan nyaman, pembayaran cashless via QRIS dan RFID Card.",
        "gambar"   => "./assets/kantin.jpg",
        "kapasitas"=> "200 Orang",
        "icon"     => "fas fa-utensils",
    ],
    [
        "kategori" => "Lapangan & Olahraga",
        "nama"     => "Lapangan Futsal Indoor",
        "deskripsi"=> "Lapangan futsal standar FIFA dengan lantai vinyl dan atap tertutup, bisa dipakai di segala cuaca.",
        "gambar"   => "./assets/futsal.jpg",
        "kapasitas"=> "40 Orang",
        "icon"     => "fas fa-futbol",
    ],
    [
        "kategori" => "Lapangan & Olahraga",
        "nama"     => "Lapangan Voli",
        "deskripsi"=> "Lapangan indoor dengan marka standar nasional.",
        "gambar"   => "./assets/volley.jpg",
        "kapasitas"=> "30 Orang",
        "icon"     => "fas fa-volleyball-ball",
    ],
    [
        "kategori" => "Lapangan & Olahraga",
        "nama"     => "Lapangan Basketball",
        "deskripsi"=> "Lapangan indoor dengan marka standar nasional.",
        "gambar"   => "./assets/basket.jpg",
        "kapasitas"=> "60 Orang",
        "icon"     => "fas fa-basketball-ball",
    ]
];
?>

<main class="flex-grow container mx-auto px-4 py-10 space-y-10">

    <!-- PAGE TITLE -->
    <div class="border-l-4 border-blue-600 pl-4">
        <h1 class="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white">Fasilitas Sekolah 🏫</h1>
        <p class="text-gray-500 dark:text-gray-400 mt-1 text-sm">Semua fasilitas yang tersedia di SMK ArknightTech untuk mendukung proses belajar siswa.</p>
    </div>

    <!-- STATS STRIP -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        <?php
        $stats = [
            ["angka" => "10+",  "label" => "Total Fasilitas",        "icon" => "fas fa-building",      "color" => "text-blue-600 dark:text-blue-400"],
            ["angka" => "3",    "label" => "Laboratorium Aktif",     "icon" => "fas fa-flask",          "color" => "text-purple-600 dark:text-purple-400"],
            ["angka" => "1.200+","label"=> "Kapasitas Total",        "icon" => "fas fa-users",          "color" => "text-green-600 dark:text-green-400"],
            ["angka" => "100%", "label" => "Berstandar Industri",    "icon" => "fas fa-award",          "color" => "text-amber-500"],
        ];
        foreach ($stats as $s): ?>
        <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 shadow-sm border border-gray-100 dark:border-gray-700 text-center">
            <i class="<?php echo $s['icon']; ?> text-2xl <?php echo $s['color']; ?> mb-2"></i>
            <p class="text-2xl font-black <?php echo $s['color']; ?>"><?php echo $s['angka']; ?></p>
            <p class="text-xs text-gray-500 dark:text-gray-400 mt-0.5"><?php echo $s['label']; ?></p>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- CARDS GRID -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        <?php foreach ($fasilitas as $fas): ?>
        <div class="bg-white dark:bg-slate-800 rounded-2xl overflow-hidden shadow-sm border border-gray-100 dark:border-gray-700 hover:-translate-y-1 hover:shadow-md transition-all duration-300 flex flex-col">

            <!-- Gambar -->
            <div class="h-44 overflow-hidden">
                <img src="<?php echo $fas['gambar']; ?>" alt="<?php echo $fas['nama']; ?>"
                     class="w-full h-full object-cover hover:scale-105 transition-transform duration-500">
            </div>

            <!-- Konten -->
            <div class="p-5 flex flex-col flex-grow">
                <span class="text-[11px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider mb-1">
                    <i class="<?php echo $fas['icon']; ?> mr-1"></i><?php echo $fas['kategori']; ?>
                </span>
                <h3 class="font-bold text-gray-900 dark:text-white text-base mb-2"><?php echo $fas['nama']; ?></h3>
                <p class="text-sm text-gray-500 dark:text-gray-400 leading-relaxed flex-grow"><?php echo $fas['deskripsi']; ?></p>

                <div class="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700 flex items-center gap-2 text-xs text-gray-400">
                    <i class="fas fa-users"></i>
                    <span>Kapasitas: <strong class="text-gray-700 dark:text-gray-200"><?php echo $fas['kapasitas']; ?></strong></span>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- CTA -->
    <div class="bg-blue-600 rounded-2xl p-6 sm:p-8 text-center text-white">
        <h2 class="text-2xl font-black mb-2">Tertarik Belajar di Sini? 🚀</h2>
        <p class="text-blue-100 text-sm mb-5">Daftarkan diri kamu dan nikmati semua fasilitas modern SMK ArknightTech.</p>
        <a href="gelombang.php" class="inline-flex items-center gap-2 bg-white text-blue-700 font-bold px-6 py-2.5 rounded-xl hover:bg-blue-50 transition text-sm">
            <i class="fas fa-user-plus"></i> Daftar PPDB Sekarang
        </a>
    </div>

</main>

<?php include './includes/footer.php'; ?>