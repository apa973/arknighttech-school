<?php 
include './includes/header.php';    

// 1. DATA ARRAY UNTUK KABAR SEKOLAH (GRID CARD)
$kabar_sekolah = [
    [
        "kategori" => "Prestasi",
        "bg_kategori" => "bg-blue-100 text-blue-800",
        "gambar" => "./assets/kabar1.jpeg",
        "judul" => "Tim SMK ArknightTech Juara 1 Lomba Web Design Nasional",
        "deskripsi" => "Tiga siswa dari jurusan Rekayasa Perangkat Lunak berhasil menyabet medali emas di ajang kompetisi IT tingkat nasional membawakan aplikasi edukasi.",
        "tanggal" => "12 Mei 2026",
        "penulis" => "Humas"
    ],
    [
        "kategori" => "Kegiatan",
        "bg_kategori" => "bg-green-100 text-green-800",
        "gambar" => "./assets/kabar2.png",
        "judul" => "Kunjungan Industri ke Perusahaan Tech Ternama di Jakarta",
        "deskripsi" => "Siswa kelas XI melaksanakan program Kunjungan Industri (KI) untuk melihat langsung bagaimana siklus kerja di dunia startup dan korporat IT.",
        "tanggal" => "05 Mei 2026",
        "penulis" => "Kesiswaan"
    ],
    [
        "kategori" => "Akademik",
        "bg_kategori" => "bg-purple-100 text-purple-800",
        "gambar" => "./assets/kabar3.jpg",
        "judul" => "Workshop UI/UX Design Bersama Praktisi Industri",
        "deskripsi" => "Mendatangkan narasumber ahli, siswa diajak praktek langsung menggunakan Figma untuk merancang antarmuka aplikasi yang user-friendly.",
        "tanggal" => "28 April 2026",
        "penulis" => "Kurikulum"
    ],
    [
        "kategori" => "Fasilitas",
        "bg_kategori" => "bg-red-100 text-red-800",
        "gambar" => "./assets/lab1.jpg",
        "judul" => "Pembaruan Komputer Lab Pemrograman Generasi ke-12",
        "deskripsi" => "Demi menunjang proses coding yang lebih cepat, sekolah resmi memperbarui 40 unit PC di lab utama dengan spesifikasi prosesor terbaru.",
        "tanggal" => "20 April 2026",
        "penulis" => "Sarpras"
    ]
];

// 2. DATA ARRAY UNTUK PAPAN PENGUMUMAN
$pengumuman = [
    [
        "tanggal" => "15",
        "bulan" => "Jun",
        "bg_tgl" => "bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400",
        "judul" => "Penilaian Akhir Semester (PAS) Genap 2026",
        "keterangan" => "Berbasis CBT di Lab Komputer"
    ],
    [
        "tanggal" => "01",
        "bulan" => "Jul",
        "bg_tgl" => "bg-green-100 dark:bg-green-900/50 text-green-600 dark:text-green-400",
        "judul" => "Gelombang Akhir Pendaftaran PPDB",
        "keterangan" => "Batas Pengembalian Berkas & Daftar Ulang"
    ],
    [
        "tanggal" => "14",
        "bulan" => "Jul",
        "bg_tgl" => "bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400",
        "judul" => "Hari Pertama Tahun Ajaran Baru & MPLS",
        "keterangan" => "Wajib bagi seluruh siswa baru kelas X"
    ]
];

// 3. DATA ARRAY BARU: JURUSAN / KONSENTRASI KEAHLIAN
$jurusan = [
    [
        "icon" => "fas fa-code",
        "nama" => "Software Engineering (RPL)",
        "deskripsi" => "Fokus pada pembuatan web app, mobile app, algoritma pemrograman, dan integrasi cloud system dengan standar industri."
    ],
    [
        "icon" => "fas fa-paint-brush",
        "nama" => "UI/UX & Digital Product Design",
        "deskripsi" => "Mempelajari riset pengguna, pembuatan wireframe, prototyping produk digital, hingga desain visual front-end yang modern."
    ],
    [
        "icon" => "fas fa-chart-line",
        "nama" => "Digital Business & Startup",
        "deskripsi" => "Kombinasi teknologi dan strategi bisnis, digital marketing, manajemen data, hingga merancang model bisnis tech startup."
    ]
];

// 4. DATA ARRAY BARU: DATA STATISTIK SEKOLAH
$statistik = [
    ["angka" => "1,200+", "label" => "Siswa Aktif", "icon" => "fas fa-user-graduate", "color" => "text-blue-600 dark:text-blue-400"],
    ["angka" => "45+", "label" => "Guru & Praktisi IT", "icon" => "fas fa-chalkboard-teacher", "color" => "text-green-600 dark:text-green-400"],
    ["angka" => "12", "label" => "Laboratorium Modern", "icon" => "fas fa-atom", "color" => "text-purple-600 dark:text-purple-400"],
    ["angka" => "98%", "label" => "Tingkat Kelulusan Kerja/Kuliah", "icon" => "fas fa-briefcase", "color" => "text-amber-500"]
];

// 5. DATA ARRAY BARU: TESTIMONI ALUMNI
$testimoni = [
    [
        "nama" => "Alvino Van Reza",
        "lulusan" => "Alumni PPLG 2025",
        "foto" => "./assets/alpin.jpeg",
        "teks" => "Berkat kurikulum coding berbasis projek di SMK ArknightTech, gwe bisa langsung keterima magang lalu diangkat jadi Front-End Developer di startup Jakarta tanpa kendala sama sekali!"
    ],
    [
        "nama" => "Muhammad Daffa",
        "lulusan" => "Alumni PPLG 2025",
        "foto" => "./assets/dapa.jpeg",
        "teks" => "Fasilitas lab-nya juara banget! Nggak cuma diajarin teori, tapi kami benar-benar di-coach cara membangun website dari awal sampai benar-benar bisa menjadi full-stack developer."
    ],
    [
        "nama" => "Muhammad Hanif Al-qarni",
        "lulusan" => "Alumni PPLG 2025",
        "foto" => "./assets/hanip.jpeg",
        "teks" => "Asli, fasilitas di sini nggak kaleng-kaleng! Belajar coding yang tadinya kelihatan pusing, malah jadi seru karena labnya nyaman dan mentornya asik diajak diskusi. Recommended banget buat yang mau fokus di dunia IT!"
    ],
    [
        "nama" => "Mahardika Syafa RIzki",
        "lulusan" => "Alumni PPLG 2025",
        "foto" => "./assets/dika.jpeg",
        "teks" => "Bener-bener dapet pengalaman belajar yang seru banget! Fasilitasnya lengkap, materi belajarnya up-to-date, dan banyak praktek langsung yang bikin kita siap buat terjun ke industri digital."
    ],
    [
        "nama" => "Razzieta Razzana Wijaya",
        "lulusan" => "Alumni PPLG 2025",
        "foto" => "./assets/zizi.jpeg",
        "teks" => "Nggak menyesal sama sekali masuk sini! Materi yang diajarin bener-bener mengikuti tren teknologi terbaru di industri. Praktik di labnya juga intensif, bikin logika programming kami jadi jauh lebih terasah."
    ],
    [
        "nama" => "Nur Safana",
        "lulusan" => "Alumni PPLG 2025",
        "foto" => "./assets/sapana.jpeg",
        "teks" => "Awalnya sempat ragu bisa ngikutin, tapi ternyata seru banget! Fasilitasnya lengkap dan atmosfer belajarnya bikin kita pengen terus berkembang. Cocok banget buat siapa saja yang mau serius mendalami dunia teknologi."
    ],
    [
        "nama" => "Chayyira Choirunnisa",
        "lulusan" => "Alumni PPLG 2025",
        "foto" => "./assets/key.jpeg",
        "teks" => "Tempat yang paling tepat buat yang mau serius di bidang teknologi. Labnya nyaman, kurikulumnya modern, dan porsi praktiknya banyak banget!"
    ],
    [
        "nama" => "Sony Habibi",
        "lulusan" => "Alumni PPLG 2025",
        "foto" => "./assets/habibi.jpeg",
        "teks" => "Tiga tahun di sini bener-bener ngebentuk cara berpikir Saya. Bukan cuma belajar teori di kelas, tapi sekolah ini juga ngajarin gimana caranya berkembang dan nemuin potensi diri. Terima kasih buat para guru yang suportif dan teman-teman yang selalu solid. Bangga banget bisa jadi bagian dari almamater ini!"
    ]
];
?>

    <main class="flex-grow container mx-auto px-4 py-6 sm:py-8 space-y-10 sm:space-y-16">
        
        <section id="page-home" class="page-section active">
            <div class="relative w-full h-[300px] sm:h-[400px] md:h-[500px] rounded-2xl overflow-hidden shadow-xl bg-gray-900">
                <div id="hero-slider" class="w-full h-full relative"></div>
                <div class="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2 z-30" id="slider-dots"></div>
            </div>
        </section>

        <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            <?php foreach ($statistik as $stat) : ?>
                <div class="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-2xl shadow-md border border-gray-100 dark:border-gray-700/50 flex items-center gap-3 sm:gap-4 hover:scale-105 transition duration-300">
                    <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gray-50 dark:bg-slate-700/50 flex items-center justify-center text-lg sm:text-xl <?php echo $stat['color']; ?> shrink-0">
                        <i class="<?php echo $stat['icon']; ?>"></i>
                    </div>
                    <div class="min-w-0">
                        <div class="text-xl sm:text-2xl font-black text-gray-900 dark:text-white tracking-tight"><?php echo $stat['angka']; ?></div>
                        <div class="text-[10px] sm:text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider leading-tight"><?php echo $stat['label']; ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </section>

        <section class="space-y-6">
            <div class="text-center max-w-xl mx-auto space-y-2">
                <span class="text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 px-3 py-1 rounded-full">Focus & Expertise</span>
                <h2 class="text-2xl sm:text-3xl font-black tracking-tight text-gray-900 dark:text-white">Program Keahlian Unggulan</h2>
                <p class="text-sm text-gray-500 dark:text-gray-400">Kurikulum berbasis kompetensi digital masa depan yang dirancang selaras dengan kebutuhan dunia kerja internasional.</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-8 pt-4">
                <?php foreach ($jurusan as $j) : ?>
                    <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700/50 relative group hover:border-blue-500 dark:hover:border-blue-500 transition-all duration-300">
                        <div class="w-12 h-12 bg-blue-600 text-white rounded-xl flex items-center justify-center text-lg shadow-lg shadow-blue-500/20 mb-4 group-hover:scale-110 transition duration-200">
                            <i class="<?php echo $j['icon']; ?>"></i>
                        </div>
                        <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-2"><?php echo $j['nama']; ?></h3>
                        <p class="text-sm text-gray-600 dark:text-gray-400 leading-relaxed"><?php echo $j['deskripsi']; ?></p>
                        <a href="rpl.php" class="mt-4 inline-flex items-center text-xs font-bold text-blue-600 dark:text-blue-400 hover:gap-2 transition-all duration-200">
                            Selengkapnya <i class="fas fa-chevron-right text-[10px] ml-1"></i>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="flex flex-col lg:flex-row gap-8 pt-4">

            <div class="w-full lg:w-2/3">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold border-l-4 border-blue-900 pl-3 dark:border-blue-400">Kabar Sekolah</h2>
                    <a href="berita.php" class="text-blue-600 dark:text-blue-400 hover:underline text-sm font-semibold">
                        Indeks Berita <i class="fas fa-arrow-right ml-1"></i>
                    </a>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <?php foreach ($kabar_sekolah as $kabar) : ?>
                        <div class="bg-white dark:bg-slate-800 rounded-xl overflow-hidden shadow-lg hover:-translate-y-2 transition-all duration-300 flex flex-col cursor-pointer">
                            <img src="<?php echo $kabar['gambar']; ?>" alt="<?php echo $kabar['kategori']; ?>" class="w-full h-48 object-cover">
                            <div class="p-4 flex-grow flex flex-col">
                                <span class="text-xs font-bold <?php echo $kabar['bg_kategori']; ?> py-1 px-2 rounded mb-2 inline-block self-start"><?php echo $kabar['kategori']; ?></span>
                                <h3 class="font-bold text-lg mb-2 hover:text-blue-700 transition line-clamp-2"><?php echo $kabar['judul']; ?></h3>
                                <p class="text-gray-600 dark:text-gray-400 text-sm mb-3 line-clamp-2"><?php echo $kabar['deskripsi']; ?></p>
                                <div class="text-xs text-gray-500 flex items-center justify-between mt-auto pt-2">
                                    <span><i class="far fa-calendar mr-1"></i> <?php echo $kabar['tanggal']; ?></span>
                                    <span><?php echo $kabar['penulis']; ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="w-full lg:w-1/3 flex flex-col gap-6">
                <div>
                    <h2 class="text-2xl font-bold border-l-4 border-yellow-500 pl-3 mb-6">Papan Pengumuman 📌</h2>
                    <div class="bg-white dark:bg-slate-800 rounded-xl shadow p-5 space-y-4">
                        
                        <?php 
                        $total_item = count($pengumuman);
                        foreach ($pengumuman as $index => $item) : 
                        ?>
                            <div class="flex gap-4 items-center cursor-pointer group">
                                <span class="w-12 h-12 rounded-lg <?php echo $item['bg_tgl']; ?> flex flex-col items-center justify-center font-bold shrink-0 leading-tight">
                                    <?php echo $item['tanggal']; ?><br><span class="text-[10px] uppercase font-semibold"><?php echo $item['bulan']; ?></span>
                                </span>
                                <div>
                                    <h4 class="font-semibold text-sm group-hover:text-blue-600 transition leading-tight dark:text-white"><?php echo $item['judul']; ?></h4>
                                    <span class="text-xs text-gray-500 dark:text-gray-400"><?php echo $item['keterangan']; ?></span>
                                </div>
                            </div>
                            
                            <?php if ($index < $total_item - 1) : ?>
                                <hr class="border-gray-100 dark:border-gray-700">
                            <?php endif; ?>

                        <?php endforeach; ?>
                        
                    </div>
                </div>



                    <div class="bg-white dark:bg-slate-800 rounded-xl overflow-hidden shadow-lg hover:-translate-y-2 transition-all duration-300 flex flex-col cursor-pointer p-5 border border-gray-100 dark:border-gray-700">
                        <div class="flex items-center gap-2 mb-4">
                            <i class="fas fa-video text-blue-500 text-lg"></i>
                            <h3 class="font-bold text-lg text-gray-900 dark:text-white">Learning HTML & CSS </h3>
                        </div>

                        <div class="relative w-full pb-[56.25%] h-0 rounded-xl overflow-hidden shadow-md">
                            <iframe
                                class="absolute top-0 left-0 w-full h-full border-0"
                                src="https://www.youtube.com/embed/qz0aGYrrlhU"
                                title="YouTube video player"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                allowfullscreen>
                            </iframe>
                        </div>

                        <div class="mt-3">
                            <h4 class="font-bold text-sm text-gray-800 dark:text-gray-200 line-clamp-1">Belajar HTML & CSS Untuk Pemula</h4>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Start your web development career with HTML/CSS! 🌐</p>
                        </div>
                    </div>

                    
            </div>
        </section>

        <section class="space-y-6">
            <h2 class="text-2xl font-bold border-l-4 border-green-500 pl-3">Kata Alumni ✨</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php foreach ($testimoni as $tst) : ?>
                    <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-md border border-gray-100 dark:border-gray-700/50 flex flex-col sm:flex-row gap-4 items-start">
                        <img src="<?php echo $tst['foto']; ?>" alt="<?php echo $tst['nama']; ?>" class="w-14 h-14 rounded-full object-cover border-2 border-blue-500 shadow-md">
                        <div class="space-y-1">
                            <p class="text-sm italic text-gray-600 dark:text-gray-300">"<?php echo $tst['teks']; ?>"</p>
                            <div class="pt-2">
                                <h4 class="text-sm font-bold text-gray-900 dark:text-white"><?php echo $tst['nama']; ?></h4>
                                <span class="text-xs font-semibold text-blue-600 dark:text-blue-400"><?php echo $tst['lulusan']; ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

    </main>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            /* === LOGIC TICKER (INFORMASI BERJALAN) === */

            /* === LOGIC CINEMATIC HERO SLIDER === */
            const slides = [
                {
                    img: './assets/banner1.jpg',
                    title: 'Mencetak Web Developer Masa Depan yang Handal',
                    tag: 'Jurusan RPL'
                },
                {
                    img: './assets/banner2.jpg',
                    title: 'Bangun Karier Tech-mu: Kuasai Web Stack Modern bareng Tech Startup.',
                    tag: 'Program Unggulan'
                },
                {
                    img: './assets/banner3.jpg',
                    title: 'Fasilitas Lab Komputer Generasi Terbaru yang Modern',
                    tag: 'Fasilitas Lab'
                }
            ];

            let currentSlide = 0;

            function renderSlider() {
                const container = document.getElementById('hero-slider');
                const dots = document.getElementById('slider-dots');
                if (!container || !dots) return;

                container.innerHTML = `
                    <div class="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent z-10"></div>
                    <div class="w-full h-full overflow-hidden absolute inset-0">
                        <img src="${slides[currentSlide].img}" class="w-full h-full object-cover animate-zoom-slider" alt="Hero Image">
                    </div>
                    <div class="absolute bottom-6 md:bottom-12 left-6 md:left-12 z-20 max-w-2xl text-white pr-6">
                        <span class="reveal-text bg-blue-600 px-3 py-1 text-xs font-bold rounded uppercase tracking-wider mb-2 md:mb-3 inline-block" style="animation-delay: 100ms;">${slides[currentSlide].tag}</span>
                        <h2 class="reveal-text text-xl sm:text-2xl md:text-4xl lg:text-5xl font-bold leading-tight mb-3 md:mb-4 drop-shadow-lg" style="animation-delay: 250ms;">${slides[currentSlide].title}</h2>
                        <a href="profil.php" class="reveal-text inline-block bg-white text-blue-900 font-bold py-1.5 px-4 md:py-2 md:px-6 rounded-full hover:bg-gray-200 transition transform hover:scale-105 active:scale-95 duration-200 shadow-md text-xs md:text-sm" style="animation-delay: 400ms;">Lihat Profil Kami</a>
                    </div>
                `;

                dots.innerHTML = slides.map((_, i) => `
                    <button aria-label="Go to slide ${i+1}" class="rounded-full cursor-pointer transition-all duration-300 ${i === currentSlide ? 'bg-blue-500 w-8 h-3 scale-100 shadow-lg shadow-blue-500/50' : 'bg-white/50 w-3 h-3 hover:bg-white/80'}" onclick="window.setSlide(${i})"></button>
                `).join('');
            }

            window.setSlide = function(index) {
                currentSlide = index;
                renderSlider();
            }

            renderSlider();
            
            setInterval(() => {
                currentSlide = (currentSlide + 1) % slides.length;
                renderSlider();
            }, 6000); 
        });
    </script>

<?php include './includes/footer.php'; ?>