<?php 
include './includes/header.php'; 

// DATA ARRAY SEJARAH - Memudahkan lu kalau mau ubah tahun atau ceritanya
$sejarah_singkat = "Didirikan pada era transformasi digital, SMK ArknightTech lahir sebagai jawaban atas tingginya kebutuhan industri akan tenaga ahli di bidang rekayasa perangkat lunak dan bisnis digital. Berawal dari sebuah komunitas riset teknologi, kini sekolah telah berkembang menjadi pusat inkubasi talenta digital muda yang dipercaya oleh belasan tech startup nasional maupun internasional.";

$milestones = [
    [
        "tahun" => "2020",
        "judul" => "Awal Mula & Komunitas Riset",
        "deskripsi" => "Berawal dari sebuah komunitas kecil tech enthusiast dan developer lokal yang fokus mengembangkan riset teknologi web dan open-source."
    ],
    [
        "tahun" => "2022",
        "judul" => "Peresmian SMK ArknightTech",
        "deskripsi" => "Resmi bertransformasi menjadi lembaga pendidikan kejuruan formal dengan fokus utama mencetak talenta di bidang Software Engineering."
    ],
    [
        "tahun" => "2024",
        "judul" => "Inkubator Startup & Akreditasi A",
        "deskripsi" => "Membuka program inkubasi bisnis digital pertama untuk tingkat sekolah, membantu siswa merancang dan merilis produk digital mereka sendiri."
    ],
    [
        "tahun" => "2026",
        "judul" => "Ekspansi & Kompetensi Global",
        "deskripsi" => "Menjalin kerja sama internasional dengan tech company global untuk penyaluran lulusan dan standarisasi kurikulum berbasis cloud dan AI."
    ]
];
?>

<main class="flex-grow container mx-auto px-4 py-6 sm:py-8 space-y-10 sm:space-y-16">
    
    <section class="page-section active">
        <div class="relative w-full h-[250px] sm:h-[350px] md:h-[400px] rounded-2xl overflow-hidden shadow-xl bg-gray-900">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10"></div>
            
            <img src="./assets/sejarah1.jpg" 
                 class="w-full h-full object-cover absolute inset-0 animate-zoom-slider" 
                 alt="Our History Background">
            
            <div class="absolute bottom-6 md:bottom-12 left-6 md:left-12 z-20 max-w-3xl text-white pr-6">
                <span class="bg-blue-600 px-3 py-1 text-xs font-bold rounded uppercase tracking-wider mb-2 md:mb-3 inline-block">Tentang Kami</span>
                <h2 class="text-2xl sm:text-3xl md:text-5xl font-black tracking-tight leading-tight mb-2 drop-shadow-lg">Sejarah Sekolah</h2>
                <p class="text-sm text-gray-200 font-medium max-w-xl drop-shadow">Kilas balik perjalanan SMK ArknightTech dalam merajut mimpi dan mencetak inovator digital masa depan.</p>
            </div>
        </div>
    </section>

    <section class="bg-white dark:bg-slate-800 p-5 sm:p-8 lg:p-10 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700/50 flex flex-col md:flex-row gap-8 items-center">
        <div class="w-full md:w-1/4 flex justify-center">
            <div class="w-20 h-20 rounded-2xl bg-blue-600 flex items-center justify-center text-white text-4xl shadow-lg shadow-blue-500/30">
                <i class="fas fa-history"></i>
            </div>
        </div>
        <div class="w-full md:w-3/4 space-y-4 text-center md:text-left">
            <h3 class="text-2xl font-black text-gray-900 dark:text-white border-l-0 md:border-l-4 border-blue-600 md:pl-3 dark:border-blue-400">Naskah Sejarah</h3>
            <p class="text-base text-gray-600 dark:text-gray-300 leading-relaxed font-normal">
                <?php echo $sejarah_singkat; ?>
            </p>
        </div>
    </section>

    <section class="space-y-8">
        <div class="border-b border-gray-200 dark:border-gray-700 pb-4">
            <h3 class="text-2xl font-black text-gray-900 dark:text-white border-l-4 border-blue-600 pl-3 dark:border-blue-400">Perjalanan Singkat</h3>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6">
            <?php foreach ($milestones as $event) : ?>
                <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-md border border-gray-100/70 dark:border-gray-700/50 flex flex-col justify-between hover:shadow-xl transition-all duration-300 group relative overflow-hidden">
                    
                    <div class="absolute top-0 left-0 right-0 h-1 bg-blue-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>

                    <div class="space-y-4">
                        <div class="inline-block px-3 py-1 bg-blue-600 text-white font-black text-sm rounded-lg shadow-md shadow-blue-500/20">
                            <?php echo $event['tahun']; ?>
                        </div>
                        
                        <h4 class="font-bold text-lg text-gray-900 dark:text-white tracking-wide group-hover:text-blue-600 dark:group-hover:text-blue-400 transition duration-200">
                            <?php echo $event['judul']; ?>
                        </h4>
                        
                        <p class="text-xs text-gray-500 dark:text-gray-400 leading-relaxed font-normal">
                            <?php echo $event['deskripsi']; ?>
                        </p>
                    </div>

                    <div class="absolute -bottom-4 -right-4 text-gray-100 dark:text-slate-700/40 text-6xl font-black select-none pointer-events-none group-hover:text-blue-500/5 transition duration-300">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

</main>

<?php 
include './includes/footer.php'; 
?>