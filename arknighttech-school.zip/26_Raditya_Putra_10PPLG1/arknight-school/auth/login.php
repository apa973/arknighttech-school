<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_name('arknight_session');

    // Hardening session cookie
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => false,  // Ganti true jika pakai HTTPS
        'httponly' => true,   // Tidak bisa diakses JS (cegah XSS)
        'samesite' => 'Strict'
    ]);

    session_start();
}

// Redirect jika sudah login — letakkan di ATAS sebelum apapun
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    header("Location: ../index.php");
    exit;
}

include 'db.php';
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error_message = "Username dan password wajib diisi!";
    } else {
        // ✅ PREPARED STATEMENT — 100% aman dari SQL Injection
        $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");

        if ($stmt) {
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows === 1) {
                $row = $result->fetch_assoc();

                // ✅ PASSWORD HASH — verifikasi bcrypt hash dari DB
                if (password_verify($password, $row['password'])) {

                    // Regenerasi session ID — cegah session fixation attack
                    session_regenerate_id(true);

                    $_SESSION['login']    = true;
                    $_SESSION['user_id']  = $row['id'];
                    $_SESSION['username'] = $row['username'];

                    // ✅ XSS-safe: escape sebelum masuk ke JS
                    $safe_username = htmlspecialchars($row['username'], ENT_QUOTES, 'UTF-8');

                    echo "<script>
                            window.location.href = '../index.php';
                          </script>";
                    exit;

                } else {
                    // Pesan generik — jangan bocorkan apakah username/password yang salah
                    $error_message = "Username atau password salah!";
                }
            } else {
                $error_message = "Username atau password salah!";
            }

            $stmt->close();
        } else {
            $error_message = "Terjadi kesalahan sistem. Coba lagi nanti.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login ArknightTech-School</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = { darkMode: 'class' }
    </script>
</head>
<body class="flex flex-col min-h-screen bg-slate-50 text-slate-900 antialiased font-sans">

    <header class="bg-white border-b border-gray-100 shadow-sm sticky top-0 z-50">
        <div class="container mx-auto px-4 h-16 flex items-center justify-between">
            <a href="../index.php" class="flex items-center gap-2.5 group">
                <div class="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white font-black text-sm shadow-md shadow-blue-500/20 group-hover:scale-105 transition">
                    A
                </div>
                <span class="font-black text-lg tracking-tight text-gray-900">
                    Arknight<span class="text-blue-600">Tech</span>
                </span>
            </a>
        </div>
    </header>

    <main class="flex-grow flex items-center justify-center px-4 py-8 sm:py-12">
        <div class="w-full max-w-md bg-white p-5 sm:p-8 rounded-2xl shadow-xl border border-gray-100/80 space-y-6">

            <div class="text-center space-y-2">
                <div class="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center text-white mx-auto shadow-md shadow-blue-500/30">
                    <i class="fas fa-laptop-code text-lg"></i>
                </div>
                <h3 class="text-2xl font-black text-gray-900 tracking-tight mt-4">Welcome To Arknighth!</h3>
                <p class="text-xs text-gray-500">Masuk ke portal digital SMK ArknightTech</p>
            </div>

            <?php if (!empty($error_message)) : ?>
                <div class="p-3 bg-red-50 border border-red-200 text-red-600 rounded-xl text-xs font-medium flex items-center gap-2">
                    <i class="fas fa-exclamation-circle text-sm text-red-500"></i>
                    <span><?php echo htmlspecialchars($error_message, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
            <?php endif; ?>

            <form action="" method="POST" class="space-y-4">

                <div class="space-y-1.5">
                    <label for="username" class="text-xs font-bold uppercase tracking-wider text-gray-400">Username</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                            <i class="fas fa-user text-xs"></i>
                        </span>
                        <input type="text" name="username" id="username" required autocomplete="off"
                               placeholder="Masukkan username"
                               class="w-full pl-9 pr-4 py-2.5 text-sm bg-gray-50 border border-gray-200 rounded-xl text-gray-900 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600">
                    </div>
                </div>

                <div class="space-y-1.5">
                    <label for="password" class="text-xs font-bold uppercase tracking-wider text-gray-400">Password</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                            <i class="fas fa-key text-xs"></i>
                        </span>
                        <input type="password" name="password" id="password" required placeholder="••••••••"
                               class="w-full pl-9 pr-10 py-2.5 text-sm bg-gray-50 border border-gray-200 rounded-xl text-gray-900 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600">
                        <button type="button" id="togglePassword"
                                class="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-blue-600">
                            <i class="fas fa-eye text-xs" id="eyeIcon"></i>
                        </button>
                    </div>
                </div>

                <div class="pt-2">
                    <button onclick="berhasil()" type="submit"
                            class="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-md transition-all active:scale-[0.98]">
                        Sign In
                    </button>
                </div>

            </form>
        </div>
    </main>

    <footer class="bg-white border-t border-gray-100 py-6 mt-auto">
        <div class="container mx-auto px-4 text-center text-xs text-gray-400">
            &copy; <?php echo date('Y'); ?> SMK ArknightTech. All rights reserved.
        </div>
    </footer>

    <script>
    const togglePassword = document.querySelector('#togglePassword');
    const passwordInput  = document.querySelector('#password');
    const eyeIcon        = document.querySelector('#eyeIcon');

    togglePassword.addEventListener('click', function () {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        eyeIcon.classList.toggle('fa-eye', type === 'password');
        eyeIcon.classList.toggle('fa-eye-slash', type === 'text');
    });
    </script>
</body>
</html>