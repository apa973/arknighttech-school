<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_arknight"; // Nama database lu di phpMyAdmin

// Variabel ini HARUS bernama $conn dan pakai satu tanda dolar ($)
$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi biar kalau gagal lu tahu masalahnya apa
if (!$conn) {
    die("Koneksi ke database gagal, jir: " . mysqli_connect_error());
}
?>