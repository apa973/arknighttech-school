<?php 
include './includes/header.php';

$info_kontak = [
    [
        "ikon" => "fas fa-map-marker-alt",
        "warna" => "blue",
        "bg" => "bg-blue-50 dark:bg-blue-950/40",
        "icon_color" => "text-blue-600 dark:text-blue-400",
        "judul" => "Alamat Sekolah",
        "isi" => "Jl. Teknologi Digital No. 99, Kec. Inovasi, Kota Depok, Jawa Barat 16400",
        "sub" => "Lihat di Google Maps"
    ],
    [
        "ikon" => "fas fa-phone-alt",
        "warna" => "green",
        "bg" => "bg-green-50 dark:bg-green-950/40",
        "icon_color" => "text-green-600 dark:text-green-400",
        "judul" => "Telepon & WhatsApp",
        "isi" => "(021) 1234-5678",
        "sub" => "+62 812-3456-7890 (WhatsApp)"
    ],
    [
        "ikon" => "fas fa-envelope",
        "warna" => "purple",
        "bg" => "bg-purple-50 dark:bg-purple-950/40",
        "icon_color" => "text-purple-600 dark:text-purple-400",
        "judul" => "Email Resmi",
        "isi" => "info@arknighttech.sch.id",
        "sub" => "humas@arknighttech.sch.id"
    ],
    [
        "ikon" => "fas fa-clock",
        "warna" => "amber",
        "bg" => "bg-amber-50 dark:bg-amber-950/40",
        "icon_color" => "text-amber-600 dark:text-amber-400",
        "judul" => "Jam Operasional",
        "isi" => "Senin – Jumat: 07.00 – 16.00 WIB",
        "sub" => "Sabtu: 07.00 – 12.00 WIB"
    ]
];

$sosmed = [
    ["ikon" => "fab fa-instagram", "label" => "Instagram", "handle" => "@arknighttech.sch", "url" => "https://www.instagram.com/arknighttech?igsh=MXhwZXRqaTAyeXQweA==", "bg" => "hover:bg-pink-500"],
    ["ikon" => "fab fa-youtube",   "label" => "YouTube",   "handle" => "ArknightTech SMK", "url" => "#", "bg" => "hover:bg-red-600"],
    ["ikon" => "fab fa-github",    "label" => "Github",    "handle" => "SMK ArknightTech", "url" => "https://github.com/apa973/shin", "bg" => "hover:bg-blue-600"],
    ["ikon" => "fab fa-tiktok",    "label" => "TikTok",    "handle" => "@arknighttech",    "url" => "https://www.tiktok.com/@arknighttech1?_r=1&_t=ZS-96n0T4bSegK", "bg" => "hover:bg-gray-800 dark:hover:bg-gray-600"],
];
?>

<main class="flex-grow container mx-auto px-4 py-6 sm:py-8 space-y-10 sm:space-y-16">

    <!-- HERO BANNER -->
    <section class="page-section active">
        <div class="relative w-full h-[250px] sm:h-[350px] md:h-[400px] rounded-2xl overflow-hidden shadow-xl bg-gray-900">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10"></div>
            <img src="./assets/contact.jpg"
                 class="w-full h-full object-cover absolute inset-0 animate-zoom-slider"
                 alt="Hubungi Kami - SMK ArknightTech">
            <div class="absolute bottom-6 md:bottom-12 left-6 md:left-12 z-20 max-w-3xl text-white pr-6">
                <span class="reveal-text bg-blue-600 px-3 py-1 text-xs font-bold rounded uppercase tracking-wider mb-2 md:mb-3 inline-block" style="animation-delay:100ms;">Kontak</span>
                <h2 class="reveal-text text-2xl sm:text-3xl md:text-5xl font-black tracking-tight leading-tight mb-2 drop-shadow-lg" style="animation-delay:250ms;">Hubungi Kami</h2>
                <p class="reveal-text text-sm text-gray-200 font-medium max-w-xl drop-shadow" style="animation-delay:400ms;">Ada pertanyaan seputar PPDB, akademik, atau fasilitas? Kami siap membantu kamu.</p>
            </div>
        </div>
    </section>

    <!-- KARTU INFO KONTAK -->
    <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        <?php foreach ($info_kontak as $kontak) : ?>
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700/50 p-6 flex flex-col gap-4 hover:shadow-md transition-all duration-300 group">
            <div class="w-12 h-12 rounded-xl <?php echo $kontak['bg']; ?> flex items-center justify-center shadow-sm group-hover:scale-105 transition duration-200">
                <i class="<?php echo $kontak['ikon']; ?> <?php echo $kontak['icon_color']; ?> text-xl"></i>
            </div>
            <div>
                <p class="text-xs font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-1"><?php echo $kontak['judul']; ?></p>
                <p class="text-sm font-bold text-gray-900 dark:text-white leading-snug"><?php echo $kontak['isi']; ?></p>
                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1"><?php echo $kontak['sub']; ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </section>

    <!-- FORM & MAPS -->
    <section class="grid grid-cols-1 lg:grid-cols-2 gap-8">

        <!-- FORM PESAN -->
        <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700/50 p-5 sm:p-8 space-y-5 sm:space-y-6">
            <div>
                <span class="text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30 px-3 py-1 rounded-full">Kirim Pesan</span>
                <h3 class="text-2xl font-black text-gray-900 dark:text-white mt-4 border-l-4 border-blue-600 pl-3">Ada yang Ingin Ditanyakan?</h3>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-2">Isi formulir di bawah ini dan tim kami akan merespons dalam 1x24 jam kerja.</p>
            </div>

            <div id="form-success" class="hidden bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-700 rounded-xl p-4">
                <div class="flex items-center gap-3">
                    <i class="fas fa-check-circle text-green-500 text-xl shrink-0"></i>
                    <p class="text-sm font-semibold text-green-700 dark:text-green-400">Pesan berhasil dikirim! Kami akan segera menghubungi kamu.</p>
                </div>
            </div>

            <div class="space-y-4">
                <div class="grid grid-cols-1 min-[400px]:grid-cols-2 gap-3 sm:gap-4">
                    <div class="space-y-1.5">
                        <label class="text-xs font-bold text-gray-600 dark:text-gray-300 uppercase tracking-wide">Nama Lengkap <span class="text-red-500">*</span></label>
                        <input type="text" id="nama" placeholder="Masukan Nama Lengkap"
                            class="w-full px-4 py-2.5 text-sm bg-gray-50 dark:bg-slate-900/50 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 focus:bg-white dark:focus:bg-slate-900 transition-all duration-200 text-gray-900 dark:text-white placeholder-gray-400">
                    </div>
                    <div class="space-y-1.5">
                        <label class="text-xs font-bold text-gray-600 dark:text-gray-300 uppercase tracking-wide">No. WhatsApp <span class="text-red-500">*</span></label>
                        <input type="text" id="wa" placeholder="08xxxxxxxxxx"
                            class="w-full px-4 py-2.5 text-sm bg-gray-50 dark:bg-slate-900/50 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 focus:bg-white dark:focus:bg-slate-900 transition-all duration-200 text-gray-900 dark:text-white placeholder-gray-400">
                    </div>
                </div>

                <div class="space-y-1.5">
                    <label class="text-xs font-bold text-gray-600 dark:text-gray-300 uppercase tracking-wide">Email</label>
                    <input type="email" id="email" placeholder="ArknightTech@gmail.com"
                        class="w-full px-4 py-2.5 text-sm bg-gray-50 dark:bg-slate-900/50 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 focus:bg-white dark:focus:bg-slate-900 transition-all duration-200 text-gray-900 dark:text-white placeholder-gray-400">
                </div>

                <div class="space-y-1.5">
                    <label class="text-xs font-bold text-gray-600 dark:text-gray-300 uppercase tracking-wide">Topik Pertanyaan <span class="text-red-500">*</span></label>
                    <select id="topik" class="w-full px-4 py-2.5 text-sm bg-gray-50 dark:bg-slate-900/50 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 focus:bg-white dark:focus:bg-slate-900 transition-all duration-200 text-gray-900 dark:text-white">
                        <option value="">-- Pilih Topik --</option>
                        <option>Informasi PPDB</option>
                        <option>Jurusan & Kurikulum</option>
                        <option>Fasilitas Sekolah</option>
                        <option>Beasiswa</option>
                        <option>E-Learning & Portal Siswa</option>
                        <option>Lainnya</option>
                    </select>
                </div>

                <div class="space-y-1.5">
                    <label class="text-xs font-bold text-gray-600 dark:text-gray-300 uppercase tracking-wide">Pesan <span class="text-red-500">*</span></label>
                    <textarea id="pesan" rows="4" placeholder="Tuliskan pertanyaan atau pesan kamu di sini..."
                        class="w-full px-4 py-2.5 text-sm bg-gray-50 dark:bg-slate-900/50 border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:border-blue-500 focus:bg-white dark:focus:bg-slate-900 transition-all duration-200 text-gray-900 dark:text-white placeholder-gray-400 resize-none"></textarea>
                </div>

                <button onclick="kirimPesan()"
                    class="w-full h-11 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-md shadow-blue-500/20 transition-all duration-200 flex items-center justify-center gap-2 active:scale-95">
                    <i class="fas fa-paper-plane"></i>
                    Kirim Pesan
                </button>
            </div>
        </div>

        <!-- MAPS & SOSMED -->
        <div class="space-y-6">

            <!-- GOOGLE MAPS EMBED -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700/50 overflow-hidden">
                <div class="p-5 border-b border-gray-100 dark:border-gray-700/50">
                    <h4 class="font-black text-gray-900 dark:text-white flex items-center gap-2">
                        <i class="fas fa-map-marked-alt text-blue-500"></i> Lokasi Sekolah
                    </h4>
                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Jl. Teknologi Digital No. 99, Depok, Jawa Barat</p>
                </div>
                <div class="relative w-full h-56 bg-gray-100 dark:bg-slate-700">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1595.7622376911413!2d106.82090312089178!3d-6.394158340482196!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69ebe390a35d75%3A0x1c8a8ffaa32fbb8b!2sPerpustakaan%20Umum%20Kota%20Depok!5e0!3m2!1sid!2sid!4v1780128670670!5m2!1sid!2sid""
                        width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade" class="absolute inset-0">
                    </iframe>
                </div>
                <div class="p-4">
                    <a href="https://maps.google.com" target="_blank"
                        class="w-full h-9 flex items-center justify-center gap-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-bold text-xs rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/50 transition">
                        <i class="fas fa-directions"></i> Buka di Google Maps
                    </a>
                </div>
            </div>

            <!-- SOSIAL MEDIA -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-gray-100 dark:border-gray-700/50 p-6 space-y-4">
                <h4 class="font-black text-gray-900 dark:text-white flex items-center gap-2">
                    <i class="fas fa-share-alt text-blue-500"></i> Ikuti Sosial Media Kami
                </h4>
                <div class="space-y-3">
                    <?php foreach ($sosmed as $s) : ?>
                    <a href="<?php echo $s['url']; ?>"
                        class="flex items-center gap-4 p-3 rounded-xl border border-gray-100 dark:border-gray-700/50 bg-gray-50/50 dark:bg-slate-900/30 <?php echo $s['bg']; ?> hover:text-white hover:border-transparent group transition-all duration-200">
                        <div class="w-9 h-9 rounded-lg bg-white dark:bg-slate-700 group-hover:bg-white/20 flex items-center justify-center shadow-sm transition duration-200">
                            <i class="<?php echo $s['ikon']; ?> text-gray-700 dark:text-gray-300 group-hover:text-white text-sm transition"></i>
                        </div>
                        <div>
                            <p class="text-xs font-black text-gray-900 dark:text-white group-hover:text-white transition"><?php echo $s['label']; ?></p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 group-hover:text-white/80 transition"><?php echo $s['handle']; ?></p>
                        </div>
                        <i class="fas fa-arrow-right ml-auto text-gray-300 dark:text-gray-600 group-hover:text-white/70 text-xs transition"></i>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>

        </div>
    </section>

    <!-- FAQ SINGKAT -->
    <section class="space-y-6">
        <div class="border-b border-gray-200 dark:border-gray-700 pb-4">
            <h3 class="text-2xl font-black text-gray-900 dark:text-white border-l-4 border-purple-600 dark:border-purple-400 pl-3">Pertanyaan yang Sering Diajukan</h3>
        </div>
        <div class="space-y-3" id="faq-container">
            <?php
            $faqs = [
                ["q" => "Bagaimana cara mendaftar PPDB SMK ArknightTech?", "a" => "Pendaftaran PPDB dilakukan secara online melalui halaman PPDB di website ini. Lengkapi formulir, upload dokumen persyaratan, lalu tunggu konfirmasi dari panitia via WhatsApp."],
                ["q" => "Apakah ada beasiswa untuk siswa berprestasi?", "a" => "Ya, sekolah menyediakan jalur beasiswa penuh dan parsial untuk calon siswa berprestasi di bidang akademik maupun teknologi informasi. Info lengkap ada di halaman PPDB."],
                ["q" => "Jurusan apa saja yang tersedia?", "a" => "SMK ArknightTech memiliki 3 jurusan: Software Engineering (RPL), UI/UX & Digital Product Design, dan Digital Business & Startup."],
                ["q" => "Apakah ada fasilitas asrama / kost untuk siswa luar kota?", "a" => "Saat ini sekolah belum menyediakan asrama, namun kami memiliki daftar rekanan kost terdekat yang aman dan terjangkau untuk siswa dari luar kota."],
            ];
            foreach ($faqs as $i => $faq) : ?>
            <div class="bg-white dark:bg-slate-800 rounded-xl border border-gray-100 dark:border-gray-700/50 overflow-hidden shadow-sm">
                <button onclick="toggleFaq(<?php echo $i; ?>)"
                    class="w-full flex items-center justify-between gap-4 p-5 text-left hover:bg-gray-50 dark:hover:bg-slate-700/30 transition">
                    <span class="text-sm font-bold text-gray-900 dark:text-white"><?php echo $faq['q']; ?></span>
                    <i id="faq-icon-<?php echo $i; ?>" class="fas fa-chevron-down text-gray-400 dark:text-gray-500 text-xs shrink-0 transition-transform duration-300"></i>
                </button>
                <div id="faq-answer-<?php echo $i; ?>" class="hidden px-5 pb-5">
                    <p class="text-sm text-gray-600 dark:text-gray-300 leading-relaxed"><?php echo $faq['a']; ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

</main>

<script>
    function kirimPesan() {
        const nama  = document.getElementById('nama').value.trim();
        const wa    = document.getElementById('wa').value.trim();
        const topik = document.getElementById('topik').value;
        const pesan = document.getElementById('pesan').value.trim();

        if (!nama || !wa || !topik || !pesan) {
            alert('Harap lengkapi semua field yang wajib diisi (*).');
            return;
        }

        // Simulasi kirim — bisa diganti fetch ke backend PHP
        document.getElementById('form-success').classList.remove('hidden');
        document.getElementById('nama').value  = '';
        document.getElementById('wa').value    = '';
        document.getElementById('email').value = '';
        document.getElementById('topik').value = '';
        document.getElementById('pesan').value = '';

        setTimeout(() => {
            document.getElementById('form-success').classList.add('hidden');
        }, 5000);
    }

    function toggleFaq(index) {
        const answer = document.getElementById('faq-answer-' + index);
        const icon   = document.getElementById('faq-icon-'   + index);
        const isOpen = !answer.classList.contains('hidden');

        // Tutup semua
        document.querySelectorAll('[id^="faq-answer-"]').forEach(el => el.classList.add('hidden'));
        document.querySelectorAll('[id^="faq-icon-"]').forEach(el => el.style.transform = '');

        if (!isOpen) {
            answer.classList.remove('hidden');
            icon.style.transform = 'rotate(180deg)';
        }
    }
</script>

<?php include './includes/footer.php'; ?>