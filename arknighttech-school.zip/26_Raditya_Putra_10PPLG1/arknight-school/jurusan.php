<?php 
include './includes/header.php'; 

// DATA ARRAY JURUSAN - Memudahkan maintenance jika ada kurikulum baru
$daftar_jurusan = [
    [
        "id" => "rpl",
        "nama" => "Software Engineering (RPL)",
        "sub_nama" => "Rekayasa Perangkat Lunak",
        "deskripsi" => "Program keahlian yang fokus pada pengembangan perangkat lunak skala industri. Siswa dididik untuk menguasai arsitektur kode yang bersih, logika algoritma yang kuat, serta siap diterjunkan sebagai *junior developer* di berbagai tech startup.",
        "ikon" => "fas fa-code",
        "warna_tema" => "blue",
        "materi" => [
            "Web Development (HTML, CSS, JavaScript, PHP, Laravel)",
            "Mobile App Development (Flutter / React Native)",
            "Database Management (MySQL, PostgreSQL, Firebase)",
            "Cloud Computing & DevOps Basics"
        ],
        "karier" => ["Fullstack Web Developer", "Mobile Programmer", "QA Engineer / Tester", "Database Administrator"],
        "sertifikasi" => "Google Associate Android Developer & AWS Certified Cloud Practitioner"
    ],
    [
        "id" => "uiux",
        "nama" => "UI/UX & Digital Product Design",
        "sub_nama" => "Desain Produk Digital",
        "deskripsi" => "Menggabungkan seni visual dengan empati terhadap pengguna. Di jurusan ini, siswa belajar cara meriset kebutuhan user, menyusun *wireframe*, membuat *prototype* yang interaktif, hingga merancang antarmuka aplikasi yang estetik dan intuitif.",
        "ikon" => "fas fa-paint-brush",
        "warna_tema" => "purple",
        "materi" => [
            "User Research & Usability Testing",
            "Information Architecture & Wireframing",
            "UI Design & Design System (Figma / Adobe XD)",
            "Design Thinking Methodologies & Micro-interactions"
        ],
        "karier" => ["UI/UX Designer", "Product Researcher", "Interaction Designer", "Visual Graphic Designer"],
        "sertifikasi" => "Google UX Design Professional Certificate"
    ],
    [
        "id" => "bd",
        "nama" => "Digital Business & Startup",
        "sub_nama" => "Bisnis Digital & Kewirausahaan",
        "deskripsi" => "Jurusan yang mencetak calon *growth hacker* dan pendiri startup masa depan. Fokus pada pemanfaatan data digital untuk strategi pemasaran, manajemen operasional bisnis berbasis teknologi, serta pengembangan model bisnis yang *scalable*.",
        "ikon" => "fas fa-chart-line",
        "warna_tema" => "amber",
        "materi" => [
            "Digital Marketing (SEO, SEM, Social Media Ads)",
            "E-Commerce & Marketplace Management",
            "Business Data Analytics & Growth Hacking",
            "Startup Pitching & Financial Modeling"
        ],
        "karier" => ["Digital Marketer", "Social Media Specialist", "Startup Founder / Co-Founder", "Business Development"],
        "sertifikasi" => "Google Digital Garage & Meta Certified Digital Marketing Associate"
    ]
];
?>

<main class="flex-grow container mx-auto px-4 py-6 sm:py-8 space-y-10 sm:space-y-16">
    
    <section class="page-section active">
        <div class="relative w-full h-[250px] sm:h-[350px] md:h-[400px] rounded-2xl overflow-hidden shadow-xl bg-gray-900">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10"></div>
            
            <img src="./assets/jurusan2.jpg" 
                 class="w-full h-full object-cover absolute inset-0 animate-zoom-slider" 
                 alt="SMK ArknightTech Students">
            
            <div class="absolute bottom-6 md:bottom-12 left-6 md:left-12 z-20 max-w-3xl text-white pr-6">
                <span class="bg-blue-600 px-3 py-1 text-xs font-bold rounded uppercase tracking-wider mb-2 md:mb-3 inline-block">Akademik</span>
                <h2 class="text-2xl sm:text-3xl md:text-5xl font-black tracking-tight leading-tight mb-2 drop-shadow-lg">Program Keahlian</h2>
                <p class="text-sm text-gray-200 font-medium max-w-xl drop-shadow">Kurikulum berbasis industri masa depan untuk melahirkan talenta digital yang kompeten dan siap kerja.</p>
            </div>
        </div>
    </section>

    <section class="space-y-8 sm:space-y-12">
        <?php foreach ($daftar_jurusan as $jurusan) : 
            // Kondisional warna kelas dinamis berbasis Tailwind
            $color = $jurusan['warna_tema'];
            $border_class = "border-$color-500 dark:border-$color-400";
            $bg_icon_class = "bg-$color-600 shadow-$color-500/30";
            if ($color === 'blue') {
                $border_class = "border-blue-600 dark:border-blue-400";
                $bg_icon_class = "bg-blue-600 shadow-blue-500/30";
                $badge_class = "bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400";
            } elseif ($color === 'purple') {
                $border_class = "border-purple-600 dark:border-purple-400";
                $bg_icon_class = "bg-purple-600 shadow-purple-500/30";
                $badge_class = "bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400";
            } else {
                $border_class = "border-amber-500 dark:border-amber-400";
                $bg_icon_class = "bg-amber-500 shadow-amber-500/30";
                $badge_class = "bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400";
            }
        ?>
            <div id="<?php echo $jurusan['id']; ?>" class="bg-white dark:bg-slate-800 rounded-2xl shadow-md border border-gray-100 dark:border-gray-700/50 p-5 sm:p-8 lg:p-10 space-y-6 sm:space-y-8 hover:shadow-lg transition-all duration-300">
                
                <div class="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-5 pb-5 sm:pb-6 border-b border-gray-100 dark:border-gray-700/60">
                    <div class="w-14 h-14 rounded-2xl <?php echo $bg_icon_class; ?> flex items-center justify-center text-white text-2xl shadow-lg shrink-0">
                        <i class="<?php echo $jurusan['ikon']; ?>"></i>
                    </div>
                    <div>
                        <span class="text-xs font-bold uppercase tracking-wider text-gray-400 dark:text-gray-500"><?php echo $jurusan['sub_nama']; ?></span>
                        <h3 class="text-xl sm:text-2xl font-black text-gray-900 dark:text-white tracking-tight mt-0.5"><?php echo $jurusan['nama']; ?></h3>
                    </div>
                </div>

                <div class="space-y-2">
                    <h4 class="text-xs font-bold uppercase tracking-widest text-gray-400">Gambaran Umum</h4>
                    <p class="text-sm text-gray-600 dark:text-gray-300 leading-relaxed font-normal">
                        <?php echo $jurusan['deskripsi']; ?>
                    </p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-8">
                    
                    <div class="space-y-4 bg-gray-50/50 dark:bg-slate-900/40 p-6 rounded-xl border border-gray-100/50 dark:border-gray-700/30">
                        <h4 class="text-xs font-bold uppercase tracking-widest text-gray-400 flex items-center gap-2">
                            <i class="fas fa-book-open text-blue-500"></i> Inti Kurikulum & Kompetensi
                        </h4>
                        <ul class="space-y-2.5">
                            <?php foreach ($jurusan['materi'] as $materi) : ?>
                                <li class="flex items-start gap-2.5 text-sm text-gray-600 dark:text-gray-300">
                                    <i class="fas fa-check-circle text-green-500 mt-1 text-xs shrink-0"></i>
                                    <span><?php echo $materi; ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                    <div class="space-y-4 bg-gray-50/50 dark:bg-slate-900/40 p-6 rounded-xl border border-gray-100/50 dark:border-gray-700/30">
                        <h4 class="text-xs font-bold uppercase tracking-widest text-gray-400 flex items-center gap-2">
                            <i class="fas fa-briefcase text-amber-500"></i> Prospek Karier Lulusan
                        </h4>
                        <div class="flex flex-wrap gap-2">
                            <?php foreach ($jurusan['karier'] as $karier) : ?>
                                <span class="text-xs font-semibold px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 shadow-sm">
                                    <?php echo $karier; ?>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    </div>

                </div>

                <div class="<?php echo $badge_class; ?> p-4 rounded-xl flex flex-col sm:flex-row sm:items-center gap-3 text-sm">
                    <div class="flex items-center gap-2 font-bold uppercase tracking-wide text-xs shrink-0">
                        <i class="fas fa-certificate text-base"></i> Sertifikasi Utama:
                    </div>
                    <div class="font-medium">
                        <?php echo $jurusan['sertifikasi']; ?>
                    </div>
                </div>

            </div>
        <?php endforeach; ?>
    </section>

</main>

<?php 
include './includes/footer.php'; 
?>