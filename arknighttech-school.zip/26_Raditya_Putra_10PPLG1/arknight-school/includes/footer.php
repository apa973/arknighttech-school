<footer class="bg-darkblue-900 text-white pt-8 sm:pt-12 pb-6 border-t-4 border-blue-600 mt-auto">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 mb-8">
                <div class="md:col-span-2">
                    <h2 class="text-2xl font-bold mb-4"><i class="fas fa-laptop-code text-blue-400"></i>ArknightTech<span class="text-blue-400">-School</span></h2>
                    <p class="text-gray-400 text-sm max-w-sm">Sekolah Menengah Kejuruan yang berfokus penuh pada Teknologi Informasi, Rekayasa Perangkat Lunak, dan Pengembangan Web (Web Development) demi mencetak talenta digital berkualitas siap kerja.</p>
                </div>
                <div>
                    <h4 class="font-bold text-lg mb-4 border-b border-gray-700 pb-2">Tautan Cepat</h4>
                    <ul class="space-y-2 text-sm text-gray-400">
                        <li><a href="profil.php" class="hover:text-blue-400 transition">Profil Sekolah</a></li>
                        <li><a href="gelombang.php" class="hover:text-blue-400 transition">Informasi PPDB 2026</a></li>
                        <li><a href="jurusan.php" class="hover:text-blue-400 transition">Jurusan</a></li>
                        <li><a href="fasilitas.php" class="hover:text-blue-400 transition">Detail Fasilitas</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-bold text-lg mb-4 border-b border-gray-700 pb-2">Sosial Media & Kontak</h4>
                    <div class="flex gap-4 mb-4">
                        <a href="https://www.tiktok.com/@arknighttech1?_r=1&_t=ZS-96ngXB2NWHh" class="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-blue-500 transition"><i class="fab fa-tiktok"></i></a>
                        <a href="https://github.com/apa973/shin" class="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-red-600 transition"><i class="fab fa-github"></i></a>
                        <a href="https://www.instagram.com/arknighttech?igsh=MXhwZXRqaTAyeXQweA==" class="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-pink-600 transition"><i class="fab fa-instagram"></i></a>
                    </div>
                    <p class="text-xs text-gray-400"><i class="fas fa-envelope mr-1"></i> info@arknighttech.sch.id</p>
                    <p class="text-xs text-gray-400 mt-1"><i class="fas fa-phone mr-1"></i> (021) 1234-5678</p>
                </div>
            </div>
            
            <div class="text-center text-xs text-gray-500 border-t border-gray-800 pt-6">
                &copy; 2026 SMK Teknologi Arknight. All rights reserved. Dibuat dengan cinta oleh Siswa RPL.    
            </div>
        </div>
    </footer>

    <script>
        const tickerItems = [
                'PPDB Gelombang 2 Telah Resmi Dibuka! Kuota Terbatas, Segera daftarkan diri Anda.',
                'SELAMAT: Tim RPL SMK ArknightTech Meraih Medali Emas di Lomba LKS Tingkat Provinsi',
                'INFO: Ujian Praktik Pemrograman Web Berbasis Projek Dilaksanakan Mulai 10 Juni',
                'BEASISWA: Tersedia jalur beasiswa penuh khusus untuk calon siswa berprestasi di bidang IT'
            ];
            
            const track = document.getElementById('ticker');
            if(track) {
                track.innerHTML = tickerItems.map(t =>
                    `<span class="inline-flex items-center gap-2.5 px-6 font-sans tracking-wide uppercase text-gray-700 dark:text-gray-200 shrink-0">
                        <span class="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-sm shadow-blue-500/50"></span>
                        <span>${t}</span>
                     </span>`
                ).join('');
            }
        /* === LOGIC MENU & DARK MODE === */
        function toggleMenu() {
            const menu = document.getElementById('mega-menu');
            if(menu) {
                menu.classList.toggle('invisible');
                menu.classList.toggle('opacity-0');
                menu.classList.toggle('-translate-y-full');
                menu.classList.toggle('translate-y-0');
                menu.classList.toggle('opacity-100');
            }
        }

        function toggleDarkMode() {
            const isDark = document.documentElement.classList.toggle('dark');
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            const icon = document.getElementById('theme-icon');
            if(icon) {
                icon.className = isDark ? 'fas fa-sun text-lg' : 'fas fa-moon text-lg';
            }
        }
    </script>
</body>
</html>