<?php
if (session_status() === PHP_SESSION_NONE) {
    session_name('arknight_session');

    // Hardening session cookie
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => false,  // Ganti true jika pakai HTTPS
        'httponly' => true,   // Tidak bisa diakses JS (cegah XSS)
        'samesite' => 'Strict'
    ]);

    session_start();
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMK ArknightTech - Sekolah Teknologi Digital</title>

    <script>
        if (localStorage.getItem('theme') === 'dark') {
            document.documentElement.classList.add('dark');
        }
    </script>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/lucid@0.1.0/dist/lucid.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* SCROLLBAR CUSTOM */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #1e3a8a; border-radius: 4px; }

        /* MOBILE BASE */
        * { box-sizing: border-box; }
        img { max-width: 100%; height: auto; }

        /* Prevent horizontal scroll on mobile */
        body { overflow-x: hidden; }

        .page-section { display: none; animation: fadeIn 0.4s ease-in-out; }
        .page-section.active { display: block; }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ANIMASI SINEMATIK SLIDER */
        @keyframes cinematicZoom {
            from { transform: scale(1); opacity: 0; }
            to { transform: scale(1.08); opacity: 1; }
        }
        .animate-zoom-slider {
            animation: cinematicZoom 6s cubic-bezier(0.25, 0.46, 0.45, 0.94) forwards;
        }

        @keyframes textRevealUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .reveal-text {
            opacity: 0;
            animation: textRevealUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
    </style>

    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        darkblue: {
                            500: '#1e3a8a', 
                            800: '#0f172a', 
                            900: '#0b1120',
                        }
                    }
                }
            }
        }
    </script>

    <script>
        // Toggle dark mode dan simpan ke localStorage
        function toggleDarkMode() {
            const isDark = document.documentElement.classList.toggle('dark');
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
            syncThemeIcon(isDark);
        }

        // Sinkronkan ikon bulan/matahari sesuai tema aktif
        function syncThemeIcon(isDark) {
            const icon = document.getElementById('theme-icon');
            if (icon) {
                icon.className = isDark ? 'fas fa-sun text-lg' : 'fas fa-moon text-lg';
            }
        }

        // Jalankan saat halaman selesai load untuk sync ikon
        document.addEventListener('DOMContentLoaded', function () {
            syncThemeIcon(document.documentElement.classList.contains('dark'));
        });
    </script>
</head>

<?php
// Pastikan session sudah dimulai sebelum header ini di-include
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($is_logged_in)) {
    $is_logged_in = isset($_SESSION['user_id']);
}
?>

<body class="bg-gray-50 text-gray-900 dark:bg-darkblue-900 dark:text-gray-100 min-h-screen font-sans transition-colors duration-300 flex flex-col">

    <header class="bg-white/80 dark:bg-darkblue-800/80 backdrop-blur-md sticky top-0 z-50 border-b border-gray-100 dark:border-gray-700 transition-colors duration-300">
        <div class="container mx-auto px-4 h-16 flex items-center justify-between gap-4">

            <!-- Logo -->
            <div class="flex items-center gap-3">
                <a href="index.php" onclick="navigate('home')" class="flex items-center gap-2 group">
                    <div class="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-500/20 group-hover:scale-105 transition duration-200">
                        <i class="fas fa-laptop-code text-lg"></i>
                    </div>
                    <h1 class="text-xl md:text-2xl font-black tracking-tight text-blue-900 dark:text-white">
                        ArknightTech<span class="text-blue-600 dark:text-blue-400">-School</span>
                    </h1>
                </a>    
            </div>

            <!-- Search Bar -->
            <div class="hidden lg:block flex-1 max-w-md">
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <i class="fas fa-search text-gray-400 text-sm"></i>
                    </span>
                    <input type="text" id="global-search" placeholder="Cari informasi PPDB, Berita, Fasilitas..." class="w-full pl-9 pr-4 py-2 text-sm bg-gray-100 dark:bg-gray-700/50 border border-transparent focus:border-blue-500 rounded-full focus:outline-none focus:bg-white dark:focus:bg-darkblue-900 transition-all duration-200">
                </div>
            </div>

            <!-- Aksi Kanan: Tema + Navbar Auth + Menu -->
            <div class="flex items-center gap-3">

                <!-- Tombol Dark Mode -->
                <button onclick="toggleDarkMode()" class="w-10 h-10 rounded-xl flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50 transition duration-200" title="Ubah Tema">
                    <i id="theme-icon" class="fas fa-moon text-lg"></i>
                </button>

                

                <!-- Auth: Login jika belum login, Logout jika sudah login -->
                <?php if (!$is_logged_in): ?>
                    <a href="auth/login.php" class="flex items-center gap-2 h-10 px-4 rounded-xl bg-blue-600/10 text-blue-600 dark:bg-blue-400/10 dark:text-blue-400 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-500 dark:hover:text-white font-bold text-sm transition-all duration-200 shadow-sm border border-blue-500/10">
                        <i class="fas fa-sign-in-alt"></i>
                        <span class="hidden sm:inline">Login</span>
                    </a>
                <?php else: ?>
                    <a href="auth/logout.php" class="flex items-center gap-2 h-10 px-4 rounded-xl bg-red-500/10 text-red-500 dark:bg-red-400/10 dark:text-red-400 hover:bg-red-500 hover:text-white dark:hover:bg-red-500 dark:hover:text-white font-bold text-sm transition-all duration-200 shadow-sm border border-red-500/10">
                        <i class="fas fa-sign-out-alt"></i>
                        <span class="hidden sm:inline">Logout</span>
                    </a>
                <?php endif; ?>

                <!-- Tombol Hamburger Menu -->
                <button onclick="toggleMenu()" class="w-10 h-10 rounded-xl flex items-center justify-center bg-blue-50 text-blue-600 dark:bg-gray-700 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-gray-600 transition duration-200" title="Buka Menu">
                    <i class="fas fa-bars text-lg"></i>
                </button>

            </div>

        </div>

        <!-- Mega Menu -->
        <div id="mega-menu" class="invisible opacity-0 -translate-y-2 absolute top-16 left-0 w-full bg-white dark:bg-darkblue-800 border-b border-gray-200 dark:border-gray-700 shadow-xl transition-all duration-300 z-40 max-h-[80vh] overflow-y-auto">
            <div class="container mx-auto px-4 py-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                
                <div class="space-y-3">
                    <h4 class="text-xs font-bold uppercase tracking-wider text-gray-400 dark:text-gray-500">Menu Navigasi</h4>
                    <ul class="space-y-1">
                        <li><a href="index.php" class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-blue-50 dark:hover:bg-gray-700/50 text-gray-700 dark:text-gray-300 font-medium transition"><i class="fas fa-home w-5 text-blue-500"></i> Beranda / Home</a></li>
                        <li><a href="profil.php" class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-blue-50 dark:hover:bg-gray-700/50 text-gray-700 dark:text-gray-300 font-medium transition"><i class="fas fa-school w-5 text-blue-500"></i> Profil Sekolah</a></li>
                        <li><a href="jurusan.php" class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-blue-50 dark:hover:bg-gray-700/50 text-gray-700 dark:text-gray-300 font-medium transition"><i class="fas fa-code w-5 text-blue-500"></i> Jurusan</a></li>
                        <li><a href="berita.php" class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-blue-50 dark:hover:bg-gray-700/50 text-gray-700 dark:text-gray-300 font-medium transition"><i class="fas fa-newspaper w-5 text-blue-500"></i> Berita & Kegiatan</a></li>
                        <li><a href="kontak.php" class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-blue-50 dark:hover:bg-gray-700/50 text-gray-700 dark:text-gray-300 font-medium transition"><i class="fas fa-address-book w-5 text-blue-500"></i> Hubungi Kami</a></li>
                        <li><a href="eskul.php" class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-blue-50 dark:hover:bg-gray-700/50 text-gray-700 dark:text-gray-300 font-medium transition"><i class="fas fa-gamepad w-5 text-blue-500"></i> Ekstrakurikuler</a></li>
                    </ul>
                </div>

                <div class="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl p-6 text-white flex flex-col justify-between shadow-lg shadow-blue-500/10">
                    <div>
                        <span class="bg-white/20 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">Tahun Ajaran 2026/2027</span>
                        <h5 class="text-lg font-bold mt-2 leading-snug">Penerimaan Siswa Baru</h5>
                        <p class="text-blue-100 text-xs mt-1">Jadilah bagian dari generasi developer masa depan. Kuasai Web Development, UI/UX, dan AI bersama fasilitas laboratorium modern.</p>
                    </div>
                    <a href="gelombang.php" class="mt-4 inline-flex items-center justify-center bg-white text-blue-600 font-bold text-xs px-4 py-2 rounded-xl hover:bg-blue-50 transition w-full">Daftar PPDB Sekarang</a>
                </div>

                <div class="bg-gray-100 dark:bg-gray-700/30 rounded-2xl p-6 flex flex-col justify-between border border-gray-200/50 dark:border-gray-700/50">
                    <div>
                        <span class="bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">Portal Siswa</span>
                        <h5 class="text-lg font-bold mt-2 leading-snug text-gray-900 dark:text-white">Akses E-Learning</h5>
                        <p class="text-gray-500 dark:text-gray-400 text-xs mt-1">Login untuk mengakses modul pembelajaran, mengumpulkan tugas coding, dan melihat jadwal ujian praktikum berbasis CBT.</p>
                    </div>
                    <a href="./auth/login.php" class="mt-4 inline-flex items-center justify-center bg-blue-600 text-white font-bold text-xs px-4 py-2 rounded-xl hover:bg-blue-700 shadow-md shadow-blue-500/10 transition w-full">Login E-Learning</a>
                </div>
            </div>
        </div>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const searchInput = document.getElementById('global-search');
                if (searchInput) {
                    searchInput.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            const keyword = this.value.toLowerCase().trim();
                            if (keyword === 'home' || keyword === 'beranda') {
                                window.location.href = 'index.php';
                            } else if (keyword === 'profil sekolah' || keyword === 'profil') {
                                window.location.href = 'profil.php';
                            } else if (keyword === 'jurusan' || keyword === 'keahlian') {
                                window.location.href = 'jurusan.php';
                            } else if (keyword === 'news' || keyword === 'berita' || keyword === 'kegiatan') {
                                window.location.href = 'berita.php';
                            } else if (keyword === 'kontak' || keyword === 'hubungi kami') {
                                window.location.href = 'kontak.php';
                            } else {
                                window.location.href = 'kategori.php?search=' + encodeURIComponent(keyword);
                            }
                        }
                    });
                }
            });
        </script>
    </header>

    <!-- Info Ticker -->
    <div class="bg-blue-50/80 dark:bg-darkblue-800/40 border-b border-gray-200/60 dark:border-gray-700/50 py-3 overflow-hidden transition-colors duration-300">
        <div class="container mx-auto px-4 flex items-center gap-3">
            <div class="flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-blue-400 whitespace-nowrap bg-blue-100/80 dark:bg-blue-950/40 px-2.5 py-1 rounded-md z-10 shadow-sm">
                <i class="fas fa-bullhorn animate-pulse"></i>
                <span>INFO SEKOLAH</span>
            </div>
            <div class="relative w-full overflow-hidden flex items-center">
                <marquee direction="left" scrollamount="5" class="w-full text-sm md:text-base font-semibold text-gray-700 dark:text-gray-200">
                    <div class="flex items-center whitespace-nowrap" id="ticker">
                    </div>
                </marquee>
            </div>
        </div>
    </div>